<?php
include "classes/dbhandler.class.php";
$dbhandler = new Dbhandler;
include "includes/header.inc.php";
?>

<style>
  /* Common styles for container and form */
  .container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #fff; /* Light gray background color */
    color: #333; /* Dark text color */
  }

  /* Form styles */
  form {
    background-color: #fff; /* White background for the form */
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    width: 100%;
    text-align: center;
  }

  form label {
    font-weight: bold;
    display: block;
    margin-bottom: 10px;
  }

  form input[type="text"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc; /* Light gray border color */
    border-radius: 5px;
    font-size: 16px;
    background-color: #f7f7f7; /* Slightly darker input background color */
    color: #333; /* Dark text color */
    margin-bottom: 15px;
  }

  form input[type="submit"] {
    background-color: #0073e6; /* Blue button background color */
    color: #fff; /* White text color */
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
  }

  form input[type="submit"]:hover {
    background-color: #0050a2; /* Darker blue on hover */
  }

  /* Table styles for user details */
  table {
    width: 100%;
    border-collapse: collapse;
    background-color: #fff; /* White background for the table */
    color: #333; /* Dark text color */
  }

  table th,
  table td {
    border: 1px solid #ccc; /* Light gray border color for table */
    padding: 10px;
    text-align: center;
  }

  /* Alternating row colors */
  table tbody tr:nth-child(even) {
    background-color: #f2f2f2;
  }

  /* Scrollable table */
  table {
    width: 50%;
    border-collapse: collapse;
    background-color: #fff; /* White background for the table */
    color: #333; /* Dark text color */
    overflow: auto; /* Enable scrolling for the table */
    max-height: 400px; /* Set a maximum height for the table */
  }
  table thead {
    background-color: #f7f7f7; /* Slightly darker header background color */
  }

  /* Error message styles */
  form p {
    color: #ff5555; /* Red text color for error messages */
    font-weight: bold;
  }

  /* Modal styles */
  .modal {
    display: none; /* Hidden by default */
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.4);
  }

  .modal-content {
    background-color: #fff;
    margin: 15% auto;
    padding: 20px;
    border: 1px solid #888;
    border-radius: 5px;
    width: 50%;
  }

  .modal-buttons {
    text-align: center;
    margin-top: 20px;
  }
  .modal-buttons button {
  background-color: #ddd; /* Gray background color for buttons */
  color: #333; /* Dark text color for buttons */
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  margin-right: 10px;
  transition: background-color 0.3s;
  }

  .modal-buttons a {
  background-color: #0073e6; /* Blue background color for Confirm Delete button */
  color: #fff; /* White text color for Confirm Delete button */
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  text-decoration: none; /* Remove underline for links */
  transition: background-color 0.3s;
  }

  .modal-buttons button:hover {
  background-color: #aaa; /* Slightly darker gray on hover for Cancel button */
  }

  .modal-buttons a:hover {
  background-color: #0050a2; /* Darker blue on hover for Confirm Delete button */
  }

</style>

<script>
  // Function to display the modal
  function showModal(usersType) {
    var modal = document.getElementById("myModal");
    modal.style.display = "block";

    // Set the 'href' of the Confirm Delete button
    var confirmDeleteButton = document.getElementById("confirmDeleteButton");
    confirmDeleteButton.href = "deleteprofile.php?users_type=" + usersType;
  }

  // Function to close the modal
  function closeModal() {
    document.getElementById("myModal").style.display = "none";
  }
</script>

<div id="myModal" class="modal">
  <div class="modal-content">
    <h3>Confirm Delete</h3>
    <p>Are you sure you want to delete this user profile?</p>
    <div class="modal-buttons">
      <button onclick="closeModal()">Cancel</button>
      <a id="confirmDeleteButton">Confirm Delete</a>
    </div>
  </div>
</div>

<?php
if ($_SESSION['type'] == "SA") :
?>

<div class="container">
  <form method="POST">
    <label for="search">Search Profile by User Type or Description:</label>
    <input type="text" name="search" id="search">
    <input type="submit" value="Search">
  </form>
  <?php
if (isset($_SESSION['success_message'])) {
  echo '<div class="success-message">' . $_SESSION['success_message'] . '</div>';
  unset($_SESSION['success_message']); // Clear the success message so it won't be displayed again
}
?>
  <?php
  if (isset($_POST['search'])) {
    $searchValue = $_POST['search'];

    // Modify the SQL query to retrieve data for the selected user based on ID or UID
    $query = "SELECT * FROM userstype WHERE users_type = :searchValue OR users_desc = :searchValue";
    $stmt = $dbhandler->connect()->prepare($query);
    $stmt->bindParam(':searchValue', $searchValue, PDO::PARAM_STR);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
      // Display user details and provide a link to update and delete the profile
      ?>
      <table>
        <thead>
          <tr>
            <th colspan="3"><h2>User Profile</h2></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>User Type</th>
            <td><?= $user['users_type']; ?></td>
          </tr>
          <tr>
            <th>User Description</th>
            <td><?= $user['users_desc']; ?></td>
          </tr>
          <tr>
            <td colspan="2">
              <a href="updateprofile.php?users_type=<?= $user['users_type']; ?>">Update</a>
              <a href="#" onclick="showModal('<?= $user['users_type']; ?>');">Delete</a>
            </td>
          </tr>
        </tbody>
      </table>
      <?php
    } else {
      echo "<p>No user profile found</p>";
    }
  } else {
    // Check if a success message is present in the URL
    if (isset($_GET['success'])) {
      $success_message = urldecode($_GET['success']);
      echo '<p>' . $success_message . '</p>';
    }
    // Display all users' profiles initially
    $users = $dbhandler->connect()->query("SELECT * FROM userstype")->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($users)) {
      ?>
      <table>
        <thead>
          <tr>
            <th colspan="6"><h2>All Users Profile</h2></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>User Type</th>
            <th>User Description</th>
          </tr>
          <?php foreach ($users as $user) : ?>
            <tr>
              <td><?= $user['users_type']; ?></td>
              <td><?= $user['users_desc']; ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php
    } else {
      echo "<p>No users' profiles found.</p>";
    }
  }
  ?>
</div>

<?php endif; ?>


<?php include "includes/footer.inc.php"; ?>