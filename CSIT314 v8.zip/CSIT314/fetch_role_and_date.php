<?php
// Assuming you have a database connection established
$connection = new mysqli("localhost", "root", "", "cafedb");

if (!$connection->connect_error) {
    if (isset($_GET['workslotid'])) {
        $workslotId = $_GET['workslotid'];

        // Query the database to retrieve the role and date information based on the selected workslot ID
        $query = "SELECT role, date FROM schedule WHERE workslotid = ?";
        $stmt = $connection->prepare($query);

        if ($stmt) {
            $stmt->bind_param("i", $workslotId); // Assuming workslotid is an integer
            $stmt->execute();
            $stmt->bind_result($role, $date);
            $stmt->fetch();

            $result = array('role' => $role, 'date' => $date);

            // Return the result as JSON
            header('Content-Type: application/json');
            echo json_encode($result);

            $stmt->close();
        }
    }
    
    $connection->close();
}
?>
