<style>
  /* Common styles for container and form */
  .container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #fff; /* Light gray background color */
    color: #333; /* Dark text color */
  }

  /* Form styles */
  form {
    background-color: #fff; /* White background for the form */
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    width: 100%;
    text-align: center;
  }

  form label {
    font-weight: bold;
    display: block;
    margin-bottom: 10px;
  }

  form input[type="text"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc; /* Light gray border color */
    border-radius: 5px;
    font-size: 16px;
    background-color: #f7f7f7; /* Slightly darker input background color */
    color: #333; /* Dark text color */
    margin-bottom: 15px;
  }

  form input[type="submit"] {
    background-color: #0073e6; /* Blue button background color */
    color: #fff; /* White text color */
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
  }

  form input[type="submit"]:hover {
    background-color: #0050a2; /* Darker blue on hover */
  }

  /* Error message styles */
  form p {
    color: #ff5555; /* Red text color for error messages */
    font-weight: bold;
  }
</style>


<?php
include "includes/header.inc.php";
require_once "classes/UserProfile.class.php";

$users_type = $_GET['users_type'];
$userProfile = new UserProfile();

$result = $userProfile->updateProfile($users_type);

if (is_array($result)) {
    $user = $result;
?>

<div class="container">
    <form method="POST">
        <label for="new_user_type">New User Type:</label>
        <input type="text" name="new_user_type" id="new_user_type" value="<?= $user['users_type'] ?>" required>
        <label for "new_user_desc">New User Description:</label>
        <input type="text" name="new_user_desc" id="new_user_desc" value="<?= $user['users_desc'] ?>" required>
        <input type="submit" name="update" value="Update Profile">
    </form>

    <?php if (isset($success_message)) : ?>
        <p><?= $success_message ?></p>
    <?php endif; ?>

    <?php if (isset($error_message)) : ?>
        <p><?= $error_message ?></p>
    <?php endif; ?>
</div>

<?php
} else {
    echo $result; // Display success or error message
}

include "includes/footer.inc.php";
?>
