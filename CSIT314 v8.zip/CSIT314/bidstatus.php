<?php
include "includes/header.inc.php";
include "includes/nav.inc.php";

class DatabaseConnection {
    private $servername = "localhost";
    private $username = "root";
    private $password = "";
    private $dbname = "cafedb";
    private $conn;

    public function __construct() {
        // Create a database connection
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);

        // Check the connection
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function getConnection() {
        return $this->conn;
    }

    public function closeConnection() {
        $this->conn->close();
    }
}

class BidStatusManager {
    private $dbConnection;

    public function __construct(DatabaseConnection $dbConnection) {
        $this->dbConnection = $dbConnection;
    }

    public function readBidStatuses() {
        $conn = $this->dbConnection->getConnection();
        $sql = "SELECT bidstatus.*, bids.employeeID, usersacc.name 
                FROM bidstatus 
                INNER JOIN bids ON bidstatus.bidID = bids.bidID
                INNER JOIN usersacc ON bids.employeeID = usersacc.employeeID";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $statuses = [];
            while ($row = $result->fetch_assoc()) {
                $statuses[] = $row;
            }
            return $statuses;
        } else {
            return [];
        }
    }
}

// Create a database connection instance
$databaseConnection = new DatabaseConnection();

// Create a bid status manager instance
$bidStatusManager = new BidStatusManager($databaseConnection);

// Read bid statuses
$bidStatuses = $bidStatusManager->readBidStatuses();

// Close the database connection
$databaseConnection->closeConnection();
?>

<style>
        body {
            text-align: center; /* Center text within the body */
        }
        table {
            margin: 0 auto; /* Center the table horizontally */
        }
</style>
<body>
    <h1>Bid Status</h1>

    <?php if (!empty($bidStatuses)): ?>
    <table border="1">
        <tr>
            <th>Bid ID</th>
            <th>Status</th>
            <th>Feedback</th>
            <th>Employee Name</th>
        </tr>
        <?php foreach ($bidStatuses as $status): ?>
        <tr>
            <td><?php echo $status['bidID']; ?></td>
            <td><?php echo $status['status']; ?></td>
            <td><?php echo $status['feedback']; ?></td>
            <td><?php echo $status['name']; ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <?php else: ?>
    <p>No bid statuses found.</p>
    <?php endif; ?>
</body>
</html>
