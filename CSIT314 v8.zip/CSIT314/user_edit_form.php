<div class="container">
    <form method="POST">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" value="<?= $user['username'] ?>" required>

        <label for="name">Name:</label>
        <input type="text" name="name" id="name" value="<?= $user['name'] ?>" required>

        <label for="phone">Phone:</label>
        <input type="text" name="phone" id="phone" value="<?= $user['phone'] ?>" required>

        <label for "email">Email:</label>
        <input type="text" name="email" id="email" value="<?= $user['email'] ?>" required>

        <label for="users_type">User Type:</label>
        <select name="users_type" id="users_type" required>
            <?php foreach ($userTypeDescriptions as $typeData) : ?>
                <option value="<?= $typeData['users_type'] ?>" <?= ($typeData['users_type'] === $user['users_type']) ? 'selected' : '' ?>>
                    <?= $typeData['users_desc'] ?>
                </option>
            <?php endforeach; ?>
        </select>

        <input type="submit" value="Update User" class="update-button">
    </form>
</div>
