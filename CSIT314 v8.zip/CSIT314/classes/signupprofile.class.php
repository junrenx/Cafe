<?php

class Signup extends DbHandler
{
  protected function setProfile($userstype, $usersdesc) 
  {
    // Prepare query
    $stm = $this->connect()->prepare('INSERT INTO userstype (users_type, users_desc) VALUES (?, ?);');


    // Execute query, Redirect user if failed to execute
    if (!$stm->execute(array($userstype, $usersdesc))) 
    {
      $stm = null;
      header("location: ../signupprofile.php?error=stmfailed");
      exit();
    }

    $stm = null;
  }

  // Function to check if usertype already exist in users db table
  protected function checktypeExist($userstype)
  {
    // Prepare query
    $stm = $this->connect()->prepare('SELECT users_type FROM userstype WHERE users_type = ?');

    // Execute query, Redirect user if failed to execute
    if (!$stm->execute(array($userstype)))
    {
      $stm = null;
      header("location: ../signupprofile.php?error=stmfailed");
      exit();
    }

    // Check if any results from the query that was executed
    $haveResults;
    // If there are results
    if ($stm-> rowCount() > 0)
    {
      $haveResults = TRUE;
    }
    else 
    {
      $haveResults = FALSE;
    }
    return $haveResults;
  }

}