<?php 

class LoginController extends Login
{
  private $username;
  private $password;

  public function __construct($username, $password)
  {
    $this->username = $username;
    $this->password = $password;
  }

  public function loginUser()
  {
    if ($this->checkEmptyInput() == TRUE)
    {
      // Empty input 
      header("location: ../index.php?error=emptyinput");
      exit();
    }

    // If passed validation
    $this->getUser($this->username, $this->password);
  }

  private function checkEmptyInput()
  {
    $empty;
    if (empty($this->username) || empty($this->password)) 
    {
      $empty = TRUE;
    }
    else 
    {
      $empty = FALSE;
    }
    return $empty;
  }
}