<?php
class WorkSlotManager {
    private $dbHandler;

    public function __construct() {
        $this->dbHandler = new DbHandler();
    }

    public function createWorkSlot($date, $role, $start_time, $end_time) {
        $conn = $this->dbHandler->connect();

        // Create a prepared statement
        $stmt = $conn->prepare("INSERT INTO schedule (date, role, start_time, end_time) VALUES (?, ?, ?, ?)");
        $stmt->execute([$date, $role, $start_time, $end_time]);

        return $stmt;
    }
    
    public function updateWorkSlot($workslotid, $newDate, $newStartTime, $newEndTime, $newRole, $newEmployeeID) {
        $conn = $this->dbHandler->connect();

        // Create a prepared statement to update the schedule
        $stmt = $conn->prepare("UPDATE schedule SET date = ?, start_time = ?, end_time = ?, role = ?, employeeID = ? WHERE workslotid = ?");
        $stmt->execute([$newDate, $newStartTime, $newEndTime, $newRole, $newEmployeeID, $workslotid]);

        return $stmt;
    }
}
?>