<?php
include "classes/dbhandler.class.php";

class UserProfile {
    private $dbhandler;

    public function __construct() {
        $this->dbhandler = new Dbhandler();
    }

    public function updateProfile($users_type) {
        
        if (isset($_SESSION['type']) && $_SESSION['type'] == "SA" && isset($_GET['users_type'])) {
            if (isset($_POST['update'])) {
                $newUserType = $_POST['new_user_type'];
                $newUserDesc = $_POST['new_user_desc'];

                $query = "UPDATE userstype SET users_type = :newUserType, users_desc = :newUserDesc WHERE users_type = :users_type";
                $stmt = $this->dbhandler->connect()->prepare($query);
                $stmt->bindParam(':newUserType', $newUserType, PDO::PARAM_STR);
                $stmt->bindParam(':newUserDesc', $newUserDesc, PDO::PARAM_STR);
                $stmt->bindParam(':users_type', $users_type, PDO::PARAM_STR);

                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "User profile updated successfully";
                    header("Location: adminviewprofile.php");
                    exit();
                } else {
                    return "Failed to update user profile";
                }                
            }

            $query = "SELECT * FROM userstype WHERE users_type = :users_type";
            $stmt = $this->dbhandler->connect()->prepare($query);
            $stmt->bindParam(':users_type', $users_type, PDO::PARAM_STR);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            return $user;
        } else {
            return "Access denied"; // Add an appropriate message for access denied.
        }
    }
}
