<?php
class Page {
    public function renderForm() {
        $form = new Form();
        $form->render();
    }

    public function renderFooter() {
        $footer = new Footer();
        $footer->render();
    }
}

class Form {
    public function render() {
        echo '<form action="includes/signupprofile.inc.php" method="post">';
        echo '<div class="form-group">';
        echo '<label for="users_type">UserType</label>';
        echo '<input type="text" id="users_type" name="users_type" placeholder="User type" required>';
        echo '</div>';
        echo '<div class="form-group">';
        echo '<label for="user_desc">User Description</label>';
        echo '<input type="text" id="users_desc" name="users_desc" placeholder="Description" required>';
        echo '</div>';
        echo '<div class="form-group">';
        echo '<button type="submit" name="submit">Create</button>';
        echo '</div>';
        echo '</form>';
    }
}

class Footer {
    public function render() {
        echo '<footer>';
        if (isset($_GET['error']) && $_GET['error'] === 'duplicate_entry') {
            $error_message = isset($_GET['message']) ? $_GET['message'] : "Duplicate entry error occurred.";
            echo "<p class='error-message'>$error_message</p>";
        }
        if (isset($_GET['error']) && $_GET['error'] === 'invalid_usertype') {
            if (isset($_GET['message'])) {
                $error_message = $_GET['message'];
                echo '<p class="error-message">' . htmlspecialchars($error_message) . '</p>';
            }
        }
        echo '</footer>';
    }
}
?>