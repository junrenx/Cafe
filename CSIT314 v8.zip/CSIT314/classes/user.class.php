<?php
class User {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function searchUser($searchValue) {
        try {
            $query = "SELECT ua.employeeID, ua.username, ua.name, ua.phone, ua.email, ua.password, ut.users_type, ut.users_desc
                      FROM usersacc ua
                      LEFT JOIN userstype ut ON ua.users_type = ut.users_type
                      WHERE ua.employeeID = :searchValue OR ua.username = :searchValue";

            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':searchValue', $searchValue, PDO::PARAM_STR);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            // Handle any database errors here
            return false;
        }
    }

    public function getAllUsers() {
        try {
            $query = "SELECT ua.employeeID, ua.username, ua.name, ua.phone, ua.email,ua.password, ut.users_type, ut.users_desc
                      FROM usersacc ua
                      LEFT JOIN userstype ut ON ua.users_type = ut.users_type";
            return $this->db->query($query)->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            // Handle any database errors here
            return [];
        }
    }

    public function deleteUser($username) {
        $this->db->beginTransaction();
    
        // Delete related records in the 'bids' table
        $stmtDeleteBids = $this->db->prepare("DELETE FROM bids WHERE employeeID = :employeeID");
        $stmtDeleteBids->bindParam(':employeeID', $username);
        
        // Delete the user from 'usersacc'
        $stmtDeleteUser = $this->db->prepare("DELETE FROM usersacc WHERE username = :username");
        $stmtDeleteUser->bindParam(':username', $username);
    
        // Attempt to execute the delete operations
        $deletedBids = $stmtDeleteBids->execute();
        $deletedUser = $stmtDeleteUser->execute();
    
        if ($deletedBids && $deletedUser) {
            $this->db->commit();
            return true; // User and related records deleted successfully
        } else {
            $this->db->rollBack();
            return false; // Failed to delete the user or related records
        }
    }
    
}
