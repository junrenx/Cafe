<?php 

class SignupController extends Signup
{
  private $userstype;
  private $usersdesc;

  // Constructor
  public function __construct($userstype, $usersdesc) 
  {
    $this->userstype = $userstype;
    $this->usersdesc = $usersdesc;
  }

  // Function to sign up user
  public function signupUser()
  {
    // Validations
    if ($this->checkEmptyInput() == TRUE)
    {
      // Empty input 
      header("location: ../signupprofile.php?error=emptyinput");
      exit();
    }

    // If passed validations
    $this->setUser($this->userstype, $this->usersdesc);
  }

  // Function to check for empty input
  private function checkEmptyInput() 
  {
    $empty;
    if (empty($this->userstype) || empty($this->usersdesc)) 
    {
      $empty = TRUE;
    }
    else 
    {
      $empty = FALSE;
    }
    return $empty;
  }

}