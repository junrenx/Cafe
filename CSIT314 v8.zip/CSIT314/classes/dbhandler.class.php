<?php

class DbHandler 
{
  public function connect()
  {
    try 
    {
      $servername = "localhost";
      $dbname = "cafedb";
      $username = "root";
      $password = "";

      $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      return $dbh;
    }
    catch (PDOException $e)
    {
      print "Error!: " . $e->getMessage() . "<br/>";
      die();
    }
  }
}

?>