<?php
require_once "classes/dbhandler.class.php";
require_once "classes/WorkSlotManager.class.php";
include "includes/header.inc.php";
include "includes/nav.inc.php";

$dbhandler = new DbHandler;
$workSlotManager = new WorkSlotManager();
$conn = $dbhandler->connect();

if (!$conn) {
    die("Database connection error: " . implode(" ", $dbhandler->errorInfo()));
}

if (isset($_GET['id'])) {
    $workslotid = $_GET['id'];

    $query = "SELECT * FROM schedule WHERE workslotid = :workslotid";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':workslotid', $workslotid);
    $stmt->execute();
    $schedule = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($schedule) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Handle form submission for updating the schedule
            $newDate = $_POST['newDate'];
            $newStartTime = $_POST['newStartTime'];
            $newEndTime = $_POST['newEndTime'];
            $newRole = $_POST['newRole'];
            $newEmployeeID = $_POST['newEmployeeID'];

            if ($workSlotManager->updateWorkSlot($workslotid, $newDate, $newStartTime, $newEndTime, $newRole, $newEmployeeID)) {
                // Redirect to the schedule view page with a success message
                header("Location: viewschedule.php?message=Schedule updated successfully");
                exit();
            } else {
                echo "Error updating schedule.";
            }
        }

        // Display the schedule update form for "CO" and "CM" users
        if ($_SESSION['type'] == "CO" || $_SESSION['type'] == "CM") {
            $employeeQuery = "SELECT employeeID, name FROM usersacc WHERE users_type = 'CS'";
            $employeeStmt = $conn->prepare($employeeQuery);
            $employeeStmt->execute();
            $selectedRole = $schedule['role'];
            $selectedEmployeeID = $schedule['employeeID'];
            
            // Create an array for role options
            $roleOptions = ['chef', 'cashier', 'waiter'];

            include "schedule_edit_form.php";
        } else {
            echo "You don't have permission to edit this schedule.";
        }
    } else {
        echo "Schedule not found.";
    }
} else {
    echo "Workslot ID not provided.";
}

include "includes/footer.inc.php";
?>
