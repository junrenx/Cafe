<?php
include "classes/dbhandler.class.php";
include "includes/header.inc.php";
include "classes/user.class.php";

$dbHandler = new DbHandler();
$db = $dbHandler->connect();

$userManagement = new User($db);

if ($_SESSION['type'] == "SA" && isset($_POST['delete'])) {
    $usernameToDelete = $_POST['delete'];
    $deleted = $userManagement->deleteUser($usernameToDelete);

    if ($deleted) {
        // Redirect back to the previous page with a success message
        header("Location: adminviewaccount.php?delete_success=1");
        exit; // Make sure to exit after the header() call
    } else {
        echo "Failed to delete the user with username $usernameToDelete.";
    }
}

include "includes/footer.inc.php";
