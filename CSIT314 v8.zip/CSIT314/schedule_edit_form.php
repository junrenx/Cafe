<style>
        .form-container {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="date"],
        input[type="time"],
        select {
            width: 90%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        input[type="submit"],
        button[type="button"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            margin-top: 20px;
            border-radius: 4px;
            font-size: 18px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }
</style>

<div class="form-container">
    <h1>Edit Schedule</h1>
    <form method="POST" id="editForm">
        <input type="hidden" name="workslotid" value="<?= $workslotid; ?>">
        <div class="form-group">
            <label for="newDate">Date:</label>
            <input type="date" name="newDate" value="<?= $schedule['date']; ?>" required>
        </div>
        <div class="form-group">
            <label for="newStartTime">Start Time:</label>
            <input type="time" name="newStartTime" value="<?= $schedule['start_time']; ?>" required>
        </div>
        <div class="form-group">
            <label for="newEndTime">End Time:</label>
            <input type="time" name="newEndTime" value="<?= $schedule['end_time']; ?>" required>
        </div>
        <div class="form-group">
            <label for="newRole">Role</label>
            <select name="newRole" required>
                <?php foreach ($roleOptions as $role) : ?>
                    <option value="<?= $role ?>" <?= ($selectedRole === $role) ? 'selected' : ''; ?>>
                        <?= ucfirst($role); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php if ($_SESSION['type'] == "CM") : ?>
            <div class="form-group">
                <label for="newEmployeeID">Employee ID:</label>
                <select name="newEmployeeID" id="newEmployeeID" required>
                    <?php while ($row = $employeeStmt->fetch(PDO::FETCH_ASSOC)) : ?>
                        <option value="<?= $row['employeeID'] ?>" <?= ($selectedEmployeeID === $row['employeeID']) ? 'selected' : ''; ?>>
                            <?= $row['name']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
        <?php endif; ?>
        <div class="form-group">
            <input type="submit" value="Update Schedule">
            <!-- Add a "Delete" button and call the JavaScript function when clicked -->
            <button type="button" id="deleteButton" onclick="showDeleteConfirmation()">Delete Schedule</button>
        </div>
    </form>
</div>

<script>
    // JavaScript function to show the delete confirmation dialog
    function showDeleteConfirmation() {
        if (confirm("Are you sure you want to delete this schedule?")) {
            // If the user confirms, submit the form to delete the schedule
            document.getElementById('editForm').action = 'deleteschedule.php'; // Update with the actual delete script
            document.getElementById('editForm').submit();
        }
    }
</script>
