<?php
include "classes/dbhandler.class.php";
include "includes/header.inc.php";
include "classes/user.class.php";?>

<style>
    
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #fff; /* Light gray background color */
  color: #333; /* Dark text color */
}

/* Form styles */
form {
  background-color: #fff; /* White background for the form */
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  max-width: 400px;
  width: 100%;
  text-align: center;
}

form label {
  font-weight: bold;
  display: block;
  margin-bottom: 10px;
}

form input[type="text"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc; /* Light gray border color */
  border-radius: 5px;
  font-size: 16px;
  background-color: #f7f7f7; /* Slightly darker input background color */
  color: #333; /* Dark text color */
  margin-bottom: 15px;
}

form input[type="submit"] {
  background-color: #0073e6; /* Blue button background color */
  color: #fff; /* White text color */
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s;
}

form input[type="submit"]:hover {
  background-color: #0050a2; /* Darker blue on hover */
}

/* Table styles for user details */
table {
  width: 100%;
  border-collapse: collapse;
  background-color: #fff; /* White background for the table */
  color: #333; /* Dark text color */
}

table th, table td {
  border: 1px solid #ccc; /* Light gray border color for table */
  padding: 10px;
  text-align: center;
}

/* Error message styles */
form p {
  color: #ff5555; /* Red text color for error messages */
  font-weight: bold;
}

a.edit-button,
button.delete-button {
  background-color: #0073e6; /* blue background color for edit button */
  color: #fff; /* White text color */
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s;
  text-decoration: none; /* Remove underline from edit link */
}

button.delete-button {
  background-color: #FF0000; /* Red background color for delete button */
}

a.edit-button:hover,
button.delete-button:hover {
  background-color: #0050a2; /* Darker blue on hover for edit button */
}

button.delete-button:hover {
  background-color: #FF3333; /* Darker red on hover for delete button */
}
</style>
<?php

$dbHandler = new DbHandler();
$db = $dbHandler->connect();

$userManagement = new User($db);

if ($_SESSION['type'] == "SA") {
    echo "<div class='container'>";
    if (isset($_GET['delete_success']) && $_GET['delete_success'] == 1) {
        echo "User has been deleted successfully.";
    }
    if (isset($_GET['success']) && $_GET['success'] == "registration") {
    echo "User has been created successfully.";
    }
    if (isset($_GET['success']) && $_GET['success'] == 1) {
        echo '<p class="success-message">User details updated successfully.</p>';
    } elseif (isset($_GET['error']) && $_GET['error'] == 1) {
        echo '<p class="error-message">Error updating user details.</p>';
    }

    echo '<form method="POST">
        <label for="search">Search User by ID or Username:</label>
        <input type="text" name="search" id="search">
        <input type="submit" value="Search">
    </form>';
    
    if (isset($_POST['search']) && !empty($_POST['search'])) {
        $searchValue = $_POST['search'];
        $user = $userManagement->searchUser($searchValue);

        if ($user) {
            echo "<table>";
            echo "<tr><th>Employee ID</th><th>Username</th><th>Name</th><th>Phone</th><th>Email</th><th>Password</th><th>User Type</th><th>Actions</th></tr>";
            echo "<tr>";
            echo "<td>{$user['employeeID']}</td>";
            echo "<td>{$user['username']}</td>";
            echo "<td>{$user['name']}</td>";
            echo "<td>{$user['phone']}</td>";
            echo "<td>{$user['email']}</td>";
            echo "<td>{$user['password']}</td>";
            echo "<td>{$user['users_type']}</td>";
            echo "<td>
                <a class='edit-button' href='edit_user.php?user_id={$user['username']}'>Update User</a>
                <form method='POST' action='delete_user.php?user_id={$user['username']}'>
                <input type='hidden' name='delete' value='{$user['username']}'>
                <button class='delete-button' type='submit'>Delete User</button>
            </form>
            </td>";
            echo "</tr>";
            echo "</table>";
            
        } else {
            echo "<p>No user found for the specified ID or username.</p>";
        }
    } else {
        $users = $userManagement->getAllUsers();

        if (!empty($users)) {
            echo "<table>";
            echo "<tr><th>Employee ID</th><th>Username</th><th>Name</th><th>Phone</th><th>Email</th><th>Password</th><th>User Type</th></tr>";
            foreach ($users as $user) {
                echo "<tr><td>{$user['employeeID']}</td><td>{$user['username']}</td><td>{$user['name']}</td><td>{$user['phone']}</td><td>{$user['email']}</td><td>{$user['password']}</td><td>{$user['users_type']}</td></tr>";
                
            }
            echo "</table>";
        } else {
            echo "<p>No users found.</p>";
        }
    }

    echo "</div>";
}
include "includes/footer.inc.php";
