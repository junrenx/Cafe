<?php
require_once "classes/dbhandler.class.php";
include "signup_form.php";
?>
