<?php
include "includes/header.inc.php";
include "includes/nav.inc.php";
include "includes/footer.inc.php";
include "WorkSlotController.php"; // Include the controller

$workSlotController = new WorkSlotController();
$workSlotController->handleRequest();
?>
