<?php
function connectToDatabase() {
    $dbhost = "localhost";
    $dbname = "cafedb";
    $username = "root";
    $password = "";

    try {
        $conn = new PDO("mysql:host=$dbhost;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Database connection error: " . $e->getMessage());
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $conn = connectToDatabase();
    
    $employeeid = $_POST["employeeid"];
    $workslotid = $_POST["workslotid"];
    $bid_role = $_POST["role"];
    $max_slots = $_POST["max_slots"];

    // Perform data validation and sanitation here if needed.

    // Verify if the employeeID exists in the usersacc table
    $userCheckQuery = "SELECT employeeID FROM usersacc WHERE employeeID = :employeeid";
    $userCheckStmt = $conn->prepare($userCheckQuery);
    $userCheckStmt->bindParam(":employeeid", $employeeid);
    $userCheckStmt->execute();
    
    if ($userCheckStmt->rowCount() > 0) {
        // The employeeID exists in the usersacc table, proceed with insertion
        // Insert the data into your bids table
        $query = "INSERT INTO bids (employeeID, workslotid, bid_role, max_slots) VALUES (:employeeid, :workslotid, :bid_role, :max_slots)";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(":employeeid", $employeeid);
        $stmt->bindParam(":workslotid", $workslotid);
        $stmt->bindParam(":bid_role", $bid_role);
        $stmt->bindParam(":max_slots", $max_slots);

        if ($stmt->execute()) {
            // Bid inserted successfully, you can now retrieve the auto-generated bid_ID
            $bid_ID = $conn->lastInsertId();
            
            // Update the bid status in the bidstatus table
            $newStatus = "pending"; // Adjust this value as needed
            $updateQuery = "INSERT INTO bidstatus (bidID, status) VALUES (:bid_ID, :newStatus)";
            $updateStmt = $conn->prepare($updateQuery);
            $updateStmt->execute([':bid_ID' => $bid_ID, ':newStatus' => $newStatus]);
            
            header("Location: cafestaff.php?message=Bid successfully");
            exit();
        } else {
            echo "Error: " . implode(" ", $stmt->errorInfo());
        }
    } else {
        echo "Error: The employeeID does not exist in the usersacc table.";
    }

    // Close the database connection when you are done
    $conn = null;
}
?>
