<?php
include "classes/dbhandler.class.php";
include "classes/workslotmanager.class.php";

class WorkSlotController {
    private $workSlotManager;

    public function __construct() {
        $this->workSlotManager = new WorkSlotManager();
    }

    public function handleRequest() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Handle form submission
            $date = $_POST['date'];
            $role = $_POST['role'];
            $start_time = $_POST['start_time'];
            $end_time = $_POST['end_time'];

            $stmt = $this->workSlotManager->createWorkSlot($date, $role, $start_time, $end_time);

            if ($stmt) {
                $success_message = "Work slot created successfully.";
            } else {
                $error_message = "Error: " . implode(" ", $stmt->errorInfo());
            }
        }

        include "workslot_form.php";
    }
}
