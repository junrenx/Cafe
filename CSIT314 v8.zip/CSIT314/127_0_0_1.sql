-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2023 at 05:21 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cafedb`
--
CREATE DATABASE IF NOT EXISTS `cafedb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cafedb`;

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `assignmentID` int(11) NOT NULL,
  `employeeID` int(11) NOT NULL,
  `workslotid` int(11) NOT NULL,
  `assigned_role` enum('chef','cashier','waiter') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bids`
--

CREATE TABLE `bids` (
  `bidID` int(11) NOT NULL,
  `employeeID` int(11) NOT NULL,
  `workslotid` int(11) NOT NULL,
  `bid_role` enum('chef','cashier','waiter') NOT NULL,
  `max_slots` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bids`
--

INSERT INTO `bids` (`bidID`, `employeeID`, `workslotid`, `bid_role`, `max_slots`) VALUES
(16, 2, 24, 'chef', 1),
(17, 2, 24, 'chef', 1),
(18, 2, 22, 'chef', 1),
(19, 2, 24, 'chef', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bidstatus`
--

CREATE TABLE `bidstatus` (
  `bidID` int(11) NOT NULL,
  `status` enum('successful','pending','rejected') NOT NULL,
  `feedback` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bidstatus`
--

INSERT INTO `bidstatus` (`bidID`, `status`, `feedback`) VALUES
(16, 'pending', NULL),
(17, 'pending', NULL),
(18, 'pending', NULL),
(19, 'pending', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `workslotid` int(11) NOT NULL,
  `employeeID` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `role` enum('chef','cashier','waiter') NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`workslotid`, `employeeID`, `date`, `role`, `start_time`, `end_time`, `created_at`, `updated_at`) VALUES
(22, 2, '2023-11-08', 'chef', '11:31:00', '11:30:00', '2023-11-06 03:29:53', '2023-11-07 15:57:41'),
(23, NULL, '2023-10-31', 'chef', '22:58:00', '10:57:00', '2023-11-07 14:55:37', '2023-11-07 14:55:37'),
(24, NULL, '2023-11-10', 'chef', '22:57:00', '00:55:00', '2023-11-07 14:55:57', '2023-11-07 14:55:57'),
(25, NULL, '2023-11-14', 'chef', '22:01:00', '22:00:00', '2023-11-07 14:58:11', '2023-11-07 14:58:11'),
(26, NULL, '2023-11-22', 'chef', '22:01:00', '22:02:00', '2023-11-07 14:59:24', '2023-11-07 14:59:24'),
(27, NULL, '2023-11-14', 'chef', '23:05:00', '13:02:00', '2023-11-07 15:02:56', '2023-11-07 15:02:56'),
(28, NULL, '2023-11-15', 'waiter', '23:12:00', '23:11:00', '2023-11-07 15:09:12', '2023-11-07 15:09:12');

-- --------------------------------------------------------

--
-- Table structure for table `usersacc`
--

CREATE TABLE `usersacc` (
  `employeeID` int(11) NOT NULL,
  `username` text NOT NULL,
  `name` text NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `users_type` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usersacc`
--

INSERT INTO `usersacc` (`employeeID`, `username`, `name`, `phone`, `email`, `password`, `users_type`) VALUES
(1, 'admin', 'asdadmin', '123', 'admin@admin.com', '$2y$10$oXn/3ne3UzYG81cVqzM0seGqDZpcMqlXIglHqpSv3rwT7oZSOyA5y', 'SA'),
(2, 'staff', 'staff', '123', 'staff@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(3, 'manager', 'manager', '123', 'manager@manager.com', '$2y$10$u2cJ1tibpWlxQQfbTpbIeOfO0G7hgcvZ213GCRSC0d/EQpiMR7Cb6', 'CM'),
(4, 'owner', 'owner', '123', 'owner@owner.com', '$2y$10$m43N1u7c8gZzFbAxAYFzZekyInkavIXFGXBEs.3.QSUpqfLPNvZ8.', 'CO');

-- --------------------------------------------------------

--
-- Table structure for table `userstype`
--

CREATE TABLE `userstype` (
  `users_type` varchar(2) NOT NULL,
  `users_desc` varchar(5000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userstype`
--

INSERT INTO `userstype` (`users_type`, `users_desc`) VALUES
('CM', 'Manager'),
('CO', 'Owner'),
('CS', 'Staff Member'),
('SA', 'System Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`assignmentID`),
  ADD KEY `employeeID` (`employeeID`),
  ADD KEY `workslotid` (`workslotid`);

--
-- Indexes for table `bids`
--
ALTER TABLE `bids`
  ADD PRIMARY KEY (`bidID`),
  ADD KEY `employeeID` (`employeeID`),
  ADD KEY `workslotid` (`workslotid`);

--
-- Indexes for table `bidstatus`
--
ALTER TABLE `bidstatus`
  ADD KEY `bidstatus_ibfk_1` (`bidID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`workslotid`),
  ADD KEY `schedule_ibfk_1` (`employeeID`);

--
-- Indexes for table `usersacc`
--
ALTER TABLE `usersacc`
  ADD PRIMARY KEY (`employeeID`),
  ADD KEY `fk_user_type` (`users_type`);

--
-- Indexes for table `userstype`
--
ALTER TABLE `userstype`
  ADD PRIMARY KEY (`users_type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `assignmentID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bids`
--
ALTER TABLE `bids`
  MODIFY `bidID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `workslotid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `usersacc`
--
ALTER TABLE `usersacc`
  MODIFY `employeeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assignments`
--
ALTER TABLE `assignments`
  ADD CONSTRAINT `assignments_ibfk_1` FOREIGN KEY (`employeeID`) REFERENCES `usersacc` (`employeeID`),
  ADD CONSTRAINT `assignments_ibfk_2` FOREIGN KEY (`workslotid`) REFERENCES `schedule` (`workslotid`);

--
-- Constraints for table `bids`
--
ALTER TABLE `bids`
  ADD CONSTRAINT `bids_ibfk_1` FOREIGN KEY (`employeeID`) REFERENCES `usersacc` (`employeeID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bids_ibfk_2` FOREIGN KEY (`workslotid`) REFERENCES `schedule` (`workslotid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bidstatus`
--
ALTER TABLE `bidstatus`
  ADD CONSTRAINT `bidstatus_ibfk_1` FOREIGN KEY (`bidID`) REFERENCES `bids` (`bidID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`employeeID`) REFERENCES `usersacc` (`employeeID`) ON DELETE CASCADE;

--
-- Constraints for table `usersacc`
--
ALTER TABLE `usersacc`
  ADD CONSTRAINT `fk_user_type` FOREIGN KEY (`users_type`) REFERENCES `userstype` (`users_type`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
