<?php
if (isset($_POST['submit'])) {
    // Include any necessary validation and database connection code here.

    // Define your form variables and sanitize user inputs.
    $username = $_POST['username'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $type = $_POST['users_type'];

    // Perform server-side validation (you can add more validation rules).
    if (empty($username) || empty($name) || empty($phone) || empty($email) || empty($password) || empty($type)) {
        header("Location: ../signup.php?error=emptyinput");
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: ../signup.php?error=invalidemail");
        exit();
    }

    // Establish a database connection (replace with your database credentials).
    $mysqli = new mysqli("localhost", "root", "", "cafedb");

    // Check for a connection error.
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }

    // Check if the username or email is already in use in the database.
    $checkQuery = "SELECT * FROM usersacc WHERE username = ? OR email = ?";
    $stmt = $mysqli->prepare($checkQuery);
    $stmt->bind_param("ss", $username, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Username or email is already taken, redirect with an error message.
        header("Location: ../signup.php?error=useroremailtaken");
        exit();
    }

    // If the username and email are not taken, proceed with user registration.

    // Securely hash the password.
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert user data into the database, including the hashed password.
    $insertQuery = "INSERT INTO usersacc (username, name, phone, email, password, users_type) VALUES (?, ?, ?, ?, ?, ?)";

    // Prepare the SQL statement.
    $stmt = $mysqli->prepare($insertQuery);

    // Bind parameters and execute the query.
    $stmt->bind_param("ssssss", $username, $name, $phone, $email, $hashedPassword, $type);

    if ($stmt->execute()) {
        // Registration successful, redirect to a success page with a success message.
        header("Location: ../adminviewaccount.php?success=registration");
    } else {
        // Registration failed, redirect with an error message.
        header("Location: ../signup.php?error=registrationfailed");
    } 

    // Close the statement and the database connection.
    $stmt->close();
    $mysqli->close();
} else {
    // Handle cases where the form is not submitted.
    header("Location: ../signup.php"); // Redirect back to the signup page.
    exit();
}
