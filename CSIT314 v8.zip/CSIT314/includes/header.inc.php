<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Cafe</title>
  <!-- Custom CSS -->
  <link rel="stylesheet" type="text/css" href="./css/header.css">
  <div class="header">
    <div class="header-container">
      <ul>
        <li><?php session_start(); echo "Welcome, " . ucfirst(strtolower($_SESSION['user'])); ?></li>
        
        <?php
        if ($_SESSION['type'] == "CS") {
          echo '<li><a href="cafestaff.php">Home</a></li>';
        } elseif ($_SESSION['type'] == "CM") {
          echo '<li><a href="cafemanager.php">Home</a></li>';
        } elseif ($_SESSION['type'] == "CO") {
          echo '<li><a href="cafeowner.php">Home</a></li>';
        } elseif ($_SESSION['type'] == "SA") {
          echo '<li><a href="systemadmin.php">Home</a></li>';
        }
        echo '<li><a href="includes/logout.inc.php">Log out</a></li>';
        ?>
      </ul>
    </div>
  </div>
</head>
  
