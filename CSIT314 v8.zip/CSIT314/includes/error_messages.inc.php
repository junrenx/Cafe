<?php
if (isset($_GET['error'])) {
    if ($_GET['error'] === 'emptyinput') {
        echo "<p>Please fill in all fields.</p>";
    }
    if ($_GET['error'] === 'invalidemail') {
        echo "<p>Invalid email address. Please enter a valid email.</p>";
    }
    if ($_GET['error'] === 'useroremailtaken') {
        echo "<p>Username or email is already taken. Please choose another one.</p>";
    }
    if ($_GET['error'] === 'none') {
        echo "<p>You have signed up successfully!</p>";
    }
}
?>
