<?php

class Login extends Dbhandler
{
  protected function getUser($username, $password) 
  {
    // Prepare statement to select data from database
    $stm = $this->connect()->prepare('SELECT password FROM usersacc WHERE username = ? OR email = ?;');

    // Validation
    if (!$stm->execute(array($username, $username)))
    {
      $stm = null;
      header("location: ../index.php?error=stmfailed");
      exit();
    }

    //If no result found from querying database
    if ($stm->rowCount() == 0) 
    {
      $stm = null;
      header("location: ../index.php?error=usernotfound");
      exit();
    }

    $hashedPwd = $stm->fetchAll(PDO::FETCH_ASSOC);
    $checkPwd = password_verify($password, $hashedPwd[0]['password']);

    // If no matching password,
    if ($checkPwd == FALSE)
    {
      $stm = null;
      header("location: ../index.php?error=wrongpassword");
      exit();
    }
    // If matched password,
    else if ($checkPwd == TRUE)
    {
     
      $stm = $this->connect()->prepare('SELECT * FROM usersacc WHERE username = ? OR email = ? OR password = ?;');
      
      // Validations for statement 
      if (!$stm->execute(array($username, $username, $password)))
      {
        $stm = null;
        header("location: ../index.php?error=stmfailed");
        exit();
      }

     
      if ($stm->rowCount() == 0)
      {
        $stm = null;
        header("location: ../index.php?error=usernotfound");
        exit();
      }

      // Proceed to login user after passed validations
      $user = $stm->fetchAll(PDO::FETCH_ASSOC);
      session_start();
      $_SESSION["user"] = $user[0]["name"];  
      $_SESSION["type"] = $user[0]["users_type"];   
      $_SESSION["username"] = $user[0]["username"];     

      $stm = null;
    }

    $stm = null;
  }
}