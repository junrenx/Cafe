<!-- Custom CSS -->
<style>
/* Common styles for all navigation bars */
.navbar {
  background-color: #333; /* Dark background color */
  padding: 10px; /* Add padding to the navigation bar */
  text-align: center;
}

/* Style links within the navigation bars */
.navbar a {
  color: #fff; /* White text color */
  text-decoration: none; /* Remove underline from links */
  margin: 0 20px; /* Add spacing between links */
  transition: color 0.3s; /* Smooth transition for link color */
  font-size: 16px; /* Set the font size */
  font-weight: bold; /* Make the text bold */
}

/* On hover, change link color and add a subtle background color */
.navbar a:hover {
  color: #00f; /* Blue link color on hover */
  background-color: #444; /* Slightly darker background on hover */
}
</style>

<?php  
// Display Cafe Owner navbar
if (isset($_SESSION['user']) && isset($_SESSION['username']) && $_SESSION['type'] == "CO") { ?>
  <div class="navbar">
    <a href=".php">Owner</a>
  </div>
  <br>
<?php } ?>

<?php 
// Display Cafe Manager navbar
if (isset($_SESSION['user']) && isset($_SESSION['username']) && $_SESSION['type'] == "CM") { ?>
  <div class="navbar">
    <a href=".php">Cafe Manager</a>
  </div>
  <br>
<?php } ?>

<?php 
// Display Cafe Staff navbar
if (isset($_SESSION['user']) && isset($_SESSION['username']) && $_SESSION['type'] == "CS") { ?>
  <div class="navbar">
    <a href=".php">STAFF</a>
  </div>
  <br>
<?php } ?>

<?php 
// Display System Admin navbar
if (isset($_SESSION['user']) && isset($_SESSION['username']) && $_SESSION['type'] == "SA") { ?>
  <div class="navbar">
  <a href="signup.php">Create Cafe User Account</a>
  <a href="signupprofile.php">Create Cafe User Profile</a>
  <a href="adminviewaccount.php">View Cafe User Account</a>
  <a href="adminviewprofile.php">View Cafe User Profile</a>
</div>
  <br>
<?php } ?>