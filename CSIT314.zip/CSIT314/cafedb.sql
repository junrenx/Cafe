-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2023 at 01:18 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cafedb`
--
CREATE DATABASE IF NOT EXISTS `cafedb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cafedb`;

-- --------------------------------------------------------

--
-- Table structure for table `usersacc`
--

CREATE TABLE `usersacc` (
  `employeeID` int(11) NOT NULL,
  `username` text NOT NULL,
  `name` text NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `users_type` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usersacc`
--

INSERT INTO `usersacc` (`employeeID`, `username`, `name`, `phone`, `email`, `password`, `users_type`) VALUES
(1, 'admin', 'admin', '123', 'admin@admin.com', '$2y$10$oXn/3ne3UzYG81cVqzM0seGqDZpcMqlXIglHqpSv3rwT7oZSOyA5y', 'SA'),
(2, 'staff', 'staff', '123', 'staff@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(3, 'manager', 'manager', '123', 'manager@manager.com', '$2y$10$u2cJ1tibpWlxQQfbTpbIeOfO0G7hgcvZ213GCRSC0d/EQpiMR7Cb6', 'CM'),
(4, 'owner', 'owner', '123', 'owner@owner.com', '$2y$10$m43N1u7c8gZzFbAxAYFzZekyInkavIXFGXBEs.3.QSUpqfLPNvZ8.', 'CO');

-- --------------------------------------------------------

--
-- Table structure for table `userstype`
--

CREATE TABLE `userstype` (
  `users_type` varchar(2) NOT NULL,
  `users_desc` varchar(5000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userstype`
--

INSERT INTO `userstype` (`users_type`, `users_desc`) VALUES
('CM', 'Manager'),
('CO', 'Owner'),
('CS', 'Staff'),
('SA', 'System Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `usersacc`
--
ALTER TABLE `usersacc`
  ADD PRIMARY KEY (`employeeID`),
  ADD KEY `fk_user_type` (`users_type`);

--
-- Indexes for table `userstype`
--
ALTER TABLE `userstype`
  ADD PRIMARY KEY (`users_type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `usersacc`
--
ALTER TABLE `usersacc`
  MODIFY `employeeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `usersacc`
--
ALTER TABLE `usersacc`
  ADD CONSTRAINT `fk_user_type` FOREIGN KEY (`users_type`) REFERENCES `userstype` (`users_type`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
