<?php
include "includes/header.inc.php";
include "classes/dbhandler.class.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dbhandler = new DbHandler;
    $conn = $dbhandler->connect();

    $workSlotID = $_POST['workslotid'];

    if (isset($_POST['delete'])) { // Check if the delete button was clicked
        // Display a confirmation modal before proceeding with the delete
        echo '<div id="confirmation-modal" style="display: block;">
                <p>Are you sure you want to delete this work slot?</p>
                <form method="POST">
                    <input type="hidden" name="workslotid" value="' . $workSlotID . '">
                    <input type="submit" name="confirmedDelete" value="Yes">
                    <input type="submit" name="cancelDelete" value="No">
                </form>
              </div>';
    } elseif (isset($_POST['confirmedDelete'])) { // Handle the confirmed delete action
        // Create a prepared statement to delete the work slot
        $stmt = $conn->prepare("DELETE FROM schedule WHERE workslotid = ?");
        $stmt->execute([$workSlotID]);

        if ($stmt) {
            header("Location: cafeowner.php?message=Work slot deleted successfully");
            exit();
        } else {
            echo "Error: " . implode(" ", $stmt->errorInfo());
        }
    } elseif (isset($_POST['update'])) { // Handle the update action as before
        // Handle form submission to update work slot
        $employeeID = $_POST['employeeID'];
        $date = $_POST['date'];
        $shiftname = $_POST['shiftname'];
        $start_time = $_POST['start_time'];
        $end_time = $_POST['end_time'];

        // Create a prepared statement to update the work slot
        $stmt = $conn->prepare("UPDATE schedule SET employeeID = ?, date = ?, shiftname = ?, start_time = ?, end_time = ? WHERE workslotid = ?");
        $stmt->execute([$employeeID, $date, $shiftname, $start_time, $end_time, $workSlotID]);

        if ($stmt) {
            echo "Work slot updated successfully.";
        } else {
            echo "Error: " . implode(" ", $stmt->errorInfo());
        }
    }
} else {
    if (isset($_GET['id'])) {
        $workSlotID = $_GET['id'];
        $dbhandler = new DbHandler;
        $conn = $dbhandler->connect();

        $stmt = $conn->prepare("SELECT * FROM schedule WHERE workslotid = ?");
        $stmt->execute([$workSlotID]);
        $workSlot = $stmt->fetch();

        if (!$workSlot) {
            echo "Work slot not found.";
            exit;
        }
    } else {
        echo "Work slot ID not provided.";
        exit;
    }
}
?>
<script>
    // JavaScript to hide the confirmation modal if the "No" button is clicked
    document.querySelector('[name="cancelDelete"]').addEventListener('click', function() {
        document.getElementById('confirmation-modal').style.display = 'none';
    });
</script>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        h1 {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        form {
            background-color: #fff;
            border: 1px solid #ccc;
            padding: 20px;
            margin: 20px auto;
            max-width: 400px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        select, input[type="date"], input[type="time"], input[type="text"] {
            width: 90%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            margin-top: 20px;
            border-radius: 4px;
            font-size: 18px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }
    /* Add CSS styles for the confirmation modal */
    #confirmation-modal {
        display: none;
        background-color: rgba(0, 0, 0, 0.6);
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    #confirmation-modal p {
        background-color: #fff;
        padding: 20px;
        text-align: center;
    }

    #confirmation-modal form {
        display: flex;
        justify-content: space-between;
    }

    #confirmation-modal input[type="submit"] {
        background-color: #333;
        color: #fff;
        border: none;
        padding: 10px 20px;
        margin-top: 20px;
        border-radius: 4px;
        font-size: 18px;
        cursor: pointer;
    }

    #confirmation-modal input[type="submit"]:hover {
        background-color: #555;
    }
</style>
<body>
    <h1>Edit Work Slot</h1>
    <form method="POST">
        <input type="hidden" name="workslotid" value="<?php echo $workSlot['workslotid']; ?>"> <!-- Update the name to match your table -->

        <label for="employeeID">Employee Name:</label>
        <select name="employeeID" id="employeeID" required>
            <?php
            $connection = mysqli_connect("localhost", "root", "", "cafedb");

            if ($connection) {
                $query = "SELECT employeeID, name FROM usersacc WHERE users_type = 'CS'";
                $result = mysqli_query($connection, $query);

                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $selected = ($row['employeeID'] == $workSlot['employeeID']) ? "selected" : "";
                        echo '<option value="' . $row['employeeID'] . '" ' . $selected . '>' . $row['name'] . '</option>';
                    }
                }

                mysqli_close($connection);
            }
            ?>
        </select><br>

        <label for="date">Date:</label>
        <input type="date" name="date" value="<?php echo $workSlot['date']; ?>" required><br>

        <label for="shiftname">Shift Name:</label>
        <input type="text" name="shiftname" value="<?php echo $workSlot['shiftname']; ?>" required><br>

        <label for="start_time">Start Time:</label>
        <input type="time" name="start_time" value="<?php echo $workSlot['start_time']; ?>" required><br>

        <label for="end_time">End Time:</label>
        <input type="time" name="end_time" value="<?php echo $workSlot['end_time']; ?>" required><br>

        <input type="submit" value="Update Work Slot">
        <input type="submit" name="delete" value="Delete Work Slot"> 
        
    </form>
</body>
</html>
 

