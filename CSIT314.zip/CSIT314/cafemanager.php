<?php include "includes/header.inc.php"; ?>
<?php include "includes/nav.inc.php"; ?>
<!DOCTYPE html>
<html lang="en">
<style>
/* styles.css */

/* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f2f2f2;
    margin: 0;
    padding: 0;
}

header {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 30px;
}

h1 {
    margin: 0;
}

.roster {
    background-color: #fff;
    padding: 20px;
    margin: 20px;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
}

/* Table Styles */
.styled-table {
    width: 100%;
    border-collapse: collapse;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
}

.styled-table th, .styled-table td {
    padding: 10px;
    text-align: left;
}

.styled-table th {
    background-color: #333;
    color: #fff;
}

.styled-table tbody tr:nth-child(even) {
    background-color: #f2f2f2;
}

.styled-table tbody tr:hover {
    background-color: #ddd;
}

/* Search Input */
#search {
    padding: 10px;
    margin-top: 10px;
    width: 100%;
    border: 1px solid #ccc;
    border-radius: 5px;
}

/* Footer Styles */
footer {
    text-align: center;
    background-color: #333;
    color: #fff;
    padding: 10px;
}
</style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cafe</title>
</head>
<body>
    <header>
        <h1>DASHBOARD
            SAMPLE
        </h1>
    </header>
    
    <section class="roster">
        <h2>Staff Roster for November 2023</h2>
        <input type="text" id="search" placeholder="Search by Name">
        <table id="roster-table">
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Name</th>
                    <th>Position</th>
                    <th>Shift Date</th>
                    <th>Shift Time</th>
                </tr>
            </thead>
            <tbody>
                <!-- JavaScript will populate this section -->
            </tbody>
        </table>
    </section>
    
    <footer>
        <p>&copy; 2023 Your Cafe Name</p>
    </footer>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- Include jQuery -->
    <script src="script.js"></script> <!-- Your custom JavaScript file -->
</body>
</html>
<script>
$(document).ready(function() {
    // Sample data (you can fetch this data from an API or a database)
    const staffRoster = [
        { id: '001', name: 'John Doe', position: 'Barista', date: '2023-11-01', time: '08:00 AM - 04:00 PM' },
        { id: '002', name: 'Jane Smith', position: 'Server', date: '2023-11-01', time: '12:00 PM - 08:00 PM' },
        // Add more staff members and shifts as needed
    ];

    // Function to populate the roster table
    function populateRosterTable(data) {
        const table = $('#roster-table tbody');
        table.empty();

        data.forEach(entry => {
            table.append(
                `<tr>
                    <td>${entry.id}</td>
                    <td>${entry.name}</td>
                    <td>${entry.position}</td>
                    <td>${entry.date}</td>
                    <td>${entry.time}</td>
                </tr>`
            );
        });
    }

    // Initial population of the table
    populateRosterTable(staffRoster);

    // Search functionality
    $('#search').on('input', function() {
        const searchTerm = $(this).val().toLowerCase();
        const filteredRoster = staffRoster.filter(entry => entry.name.toLowerCase().includes(searchTerm));
        populateRosterTable(filteredRoster);
    });
});
</script>

<?php include "includes/footer.inc.php"; ?>
