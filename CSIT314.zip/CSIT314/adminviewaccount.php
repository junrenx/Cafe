<?php
include "classes/dbhandler.class.php";
$dbhandler = new Dbhandler;
include "includes/header.inc.php";?>
<style>/* Common styles for container and form */
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #fff; /* Light gray background color */
  color: #333; /* Dark text color */
}

/* Form styles */
form {
  background-color: #fff; /* White background for the form */
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  max-width: 400px;
  width: 100%;
  text-align: center;
}

form label {
  font-weight: bold;
  display: block;
  margin-bottom: 10px;
}

form input[type="text"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc; /* Light gray border color */
  border-radius: 5px;
  font-size: 16px;
  background-color: #f7f7f7; /* Slightly darker input background color */
  color: #333; /* Dark text color */
  margin-bottom: 15px;
}

form input[type="submit"] {
  background-color: #0073e6; /* Blue button background color */
  color: #fff; /* White text color */
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s;
}

form input[type="submit"]:hover {
  background-color: #0050a2; /* Darker blue on hover */
}

/* Table styles for user details */
table {
  width: 100%;
  border-collapse: collapse;
  background-color: #fff; /* White background for the table */
  color: #333; /* Dark text color */
}

table th, table td {
  border: 1px solid #ccc; /* Light gray border color for table */
  padding: 10px;
  text-align: center;
}

/* Error message styles */
form p {
  color: #ff5555; /* Red text color for error messages */
  font-weight: bold;
}

a.edit-button,
button.delete-button {
  background-color: #0073e6; /* blue background color for edit button */
  color: #fff; /* White text color */
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s;
  text-decoration: none; /* Remove underline from edit link */
}

button.delete-button {
  background-color: #FF0000; /* Red background color for delete button */
}

a.edit-button:hover,
button.delete-button:hover {
  background-color: #0050a2; /* Darker blue on hover for edit button */
}

button.delete-button:hover {
  background-color: #FF3333; /* Darker red on hover for delete button */
}

</style>
<?php if ($_SESSION['type'] == "SA") : ?>
    <div class="container">
        <form method="POST">
            <label for="search">Search User by ID or Username:</label>
            <input type="text" name="search" id="search">
            <input type="submit" value="Search">
        </form>

        <?php
        if (isset($_POST['search'])) {
            $searchValue = $_POST['search'];

            // Modify the SQL query to retrieve data for the selected user based on employeeID or username
            $query = "SELECT ua.employeeID, ua.username, ua.name, ua.phone, ua.email, ut.users_type, ut.users_desc
          FROM usersacc ua
          LEFT JOIN userstype ut ON ua.users_type = ut.users_type
          WHERE ua.employeeID = :searchValue OR ua.username = :searchValue";

            $stmt = $dbhandler->connect()->prepare($query);
            $stmt->bindParam(':searchValue', $searchValue, PDO::PARAM_STR);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Display user details
                ?>
                <table>
                    <thead>
                        <tr>
                            <th colspan="2"><h2>User Details</h2></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>Employee ID</th>
                            <td><?= $user['employeeID']; ?></td>
                        </tr>
                        <tr>
                            <th>Username</th>
                            <td><?= $user['username']; ?></td>
                        </tr>
                        <tr>
                            <th>Name</th>
                            <td><?= $user['name']; ?></td>
                        </tr>
                        <tr>
                            <th>Phone</th>
                            <td><?= $user['phone']; ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?= $user['email']; ?></td>
                        </tr>
                        <tr>
                            <th>User Type</th>
                            <td><?= $user['users_desc']; ?></td>
                        </tr>
                        <tr>
                        <td colspan="2">
  <a class="edit-button" href="edit_user.php?user_id=<?= $user['username']; ?>">Update User</a>
  <button class="delete-button" data-username="<?= $user['username']; ?>">Delete User</button>
</td>

            </tr>
                    </tbody>
                </table>
                <?php
            } else {
              echo "<p>No user found for the specified ID or username.</p>";
            }
        } else {
            // Display all users initially
            $users = $dbhandler->connect()->query("SELECT ua.employeeID, ua.username, ua.name, ua.phone, ua.email, ut.users_type, ut.users_desc
            FROM usersacc ua
            LEFT JOIN userstype ut ON ua.users_type = ut.users_type")->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($users)) {
                ?>
                <table>
                    <thead>
                        <tr>
                            <th colspan="6"><h2>All Users</h2></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>Employee ID</th>
                            <th>Username</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>User Type</th>
                        </tr>
                        <?php foreach ($users as $user) : ?>
                            <tr>
                                <td><?= $user['employeeID']; ?></td>
                                <td><?= $user['username']; ?></td>
                                <td><?= $user['name']; ?></td>
                                <td><?= $user['phone']; ?></td>
                                <td><?= $user['email']; ?></td>
                                <td><?= $user['users_desc']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php
            } else {
                echo "<p>No users found.</p>";
            }
        }
        ?>
    </div>
<?php endif; ?>

<?php include "includes/footer.inc.php"; ?>

<script>
    // Function to open a confirmation modal
    function openDeleteModal(username) {
        const modal = document.getElementById("deleteModal");
        modal.style.display = "block";

        const confirmButton = document.getElementById("confirmDelete");
        confirmButton.addEventListener("click", function () {
            // Redirect to delete_user.php with confirmed=true and username
            window.location.href = `delete_user.php?confirmed=true&user_id=${username}`;
        });

        const cancelButton = document.getElementById("cancelDelete");
        cancelButton.addEventListener("click", function () {
            modal.style.display = "none";
        });
    }

    // Add a click event listener to all Delete buttons
    const deleteButtons = document.querySelectorAll(".delete-button");
    deleteButtons.forEach((button) => {
        button.addEventListener("click", function () {
            const username = button.getAttribute("data-username");
            openDeleteModal(username);
        });
    });
</script>

<!-- The Modal -->
<div id="deleteModal" class="modal">
    <div class="modal-content">
        <span id="cancelDelete" class="close">&times;</span>
        <p>Are you sure you want to delete this user?</p>
        <button id="confirmDelete">Confirm</button>
    </div>
</div>

<style>
    /* Add this CSS for the modal */
    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        padding-top: 100px;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.4);
    }

    .modal-content {
        background-color: #fefefe;
        margin: auto;
        padding: 20px;
        border: 1px solid #888;
        width: 60%;
        text-align: center;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
</style>
