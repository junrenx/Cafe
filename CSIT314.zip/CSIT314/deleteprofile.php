<?php
include "classes/dbhandler.class.php";
$dbhandler = new Dbhandler;
include "includes/header.inc.php";

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['users_type'])) {
    $users_type = $_GET['users_type'];

    // Check if the user profile exists before deleting it
    $query = "SELECT * FROM userstype WHERE users_type = :users_type";
    $stmt = $dbhandler->connect()->prepare($query);
    $stmt->bindParam(':users_type', $users_type, PDO::PARAM_STR);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Perform the deletion
        $deleteQuery = "DELETE FROM userstype WHERE users_type = :users_type";
        $deleteStmt = $dbhandler->connect()->prepare($deleteQuery);
        $deleteStmt->bindParam(':users_type', $users_type, PDO::PARAM_STR);
        if ($deleteStmt->execute()) {
            // Deletion successful
            $success_message = "User profile deleted successfully.";
            header("Location: adminviewprofile.php?success=" . urlencode($success_message));
            exit;
        } else {
            // Deletion failed
            $error_message = "Failed to delete the user profile. Please try again.";
        }
    } else {
        // User profile does not exist
        $error_message = "User profile not found.";
    }
} else {
    // Invalid or missing parameter
    $error_message = "Invalid request.";
}

// Display error message if any
if (isset($error_message)) {
    echo "<p>Error: " . $error_message . "</p>";
}

include "includes/footer.inc.php";
?>
