<?php
include "classes/dbhandler.class.php";

$dbhandler = new DbHandler;
$conn = $dbhandler->connect();

if (!$conn) {
    die("Database connection error: " . implode(" ", $dbhandler->errorInfo()));
}

include "includes/header.inc.php";
include "includes/nav.inc.php";
?>

<style>
    h1 {
        margin: 20px;
        color: #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ccc;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    tr:nth-child(odd) {
        background-color: #fff;
    }
    .message {
        text-align: center; /* Center text horizontally */
        color: #FF0000; /* White text color */
        padding: 10px; /* Add padding for better appearance */
    }
</style>

<h1>View Schedule</h1>

<?php if (isset($_GET['message'])) {
    echo '<div class="message">' . $_GET['message'] . '</div>';
}

$dbhandler = new DbHandler;
$conn = $dbhandler->connect();

$query = "SELECT schedule.*, usersacc.name
          FROM schedule
          INNER JOIN usersacc ON schedule.employeeID = usersacc.employeeID
          ORDER BY schedule.date, schedule.start_time";

$result = $conn->query($query);

if ($result) {
    if ($result->rowCount() > 0) {
        echo "<table>
        <tr>
            <th>Employee Name</th>
            <th>Employee ID</th>
            <th>Date</th>
            <th>Shift Name</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Update/Delete</th>
        </tr>";

        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>
                <td>" . htmlspecialchars($row['name']) . "</td>
                <td>" . htmlspecialchars($row['employeeID']) . "</td>
                <td>" . htmlspecialchars($row['date']) . "</td>
                <td>" . htmlspecialchars($row['shiftname']) . "</td>
                <td>" . htmlspecialchars($row['start_time']) . "</td>
                <td>" . htmlspecialchars($row['end_time']) . "</td>
                <td><a href='editworkslot.php?id=" . $row['workslotid'] . "'>Edit</a></td>
            </tr>";
        }

        echo "</table>";

    } else {
        echo "No schedules found.";
    }
} else {
    echo "Error: " . implode(" ", $conn->errorInfo());
}

include "includes/footer.inc.php";
?>

