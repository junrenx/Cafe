CREATE DATABASE `cafedb`;
use `cafedb`;
CREATE TABLE `usersacc` (
  `users_id` int(11) NOT NULL AUTO_INCREMENT,
  `users_uid` text NOT NULL,
  `users_fname` text NOT NULL,
  `users_lname` text NOT NULL,
  `users_phone` varchar(20) NOT NULL,
  `users_email` text NOT NULL,
  `users_pwd` text NOT NULL,
  `users_type` varchar(2) NOT NULL,
  PRIMARY KEY (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cafedb`.`usersacc` (`users_id`, `users_uid`, `users_fname`, `users_lname`, `users_phone`, `users_email`, `users_pwd`, `users_type`) VALUES ('1', 'admin', 'admin', 'admin', '123', 'admin@admin.com', '$2y$10$oXn/3ne3UzYG81cVqzM0seGqDZpcMqlXIglHqpSv3rwT7oZSOyA5y', 'SA');
INSERT INTO `cafedb`.`usersacc` (`users_id`, `users_uid`, `users_fname`, `users_lname`, `users_phone`, `users_email`, `users_pwd`, `users_type`) VALUES ('2', 'staff', 'staff', 'staff', '123', 'staff@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS');
INSERT INTO `cafedb`.`usersacc` (`users_id`, `users_uid`, `users_fname`, `users_lname`, `users_phone`, `users_email`, `users_pwd`, `users_type`) VALUES ('3', 'manager', 'manager', 'manager', '123', 'manager@manager.com', '$10$6YyXkBy5RLE43wihVTMdsulkamIx51gW0CLL16e4YA6gCSWdXthpa', 'CM');
INSERT INTO `cafedb`.`usersacc` (`users_id`, `users_uid`, `users_fname`, `users_lname`, `users_phone`, `users_email`, `users_pwd`, `users_type`) VALUES ('4', 'owner', 'owner', 'owner', '123', 'owner@owner.com', '$2y$10$m43N1u7c8gZzFbAxAYFzZekyInkavIXFGXBEs.3.QSUpqfLPNvZ8.', 'CO');

