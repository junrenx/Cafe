<?php
include "classes/dbhandler.class.php";
$dbhandler = new Dbhandler;

include "includes/header.inc.php";
?>

<style>
    table {
        margin: auto;
        width: 60%;
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid black;
        padding: 10px;
        text-align: center;
    }
</style>

<?php if ($_SESSION['type'] == "SA") : ?>
    <div class="container">
        <form method="POST">
            <label for="search">Search User by ID or UID:</label>
            <input type="text" name="search" id="search">
            <input type="submit" value="Search">
        </form>

        <?php
        if (isset($_POST['search'])) {
            $searchValue = $_POST['search'];

            // Modify the SQL query to retrieve data for the selected user based on ID or UID
            $query = "SELECT * FROM usersacc WHERE users_uid = :searchValue OR users_id = :searchValue";
            $stmt = $dbhandler->connect()->prepare($query);
            $stmt->bindParam(':searchValue', $searchValue, PDO::PARAM_STR);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Display user details
                ?>
                <table>
                    <thead>
                        <tr>
                            <th colspan="2"><h2>User Details</h2></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>ID</th>
                            <td><?= $user['users_id']; ?></td>
                        </tr>
                        <tr>
                            <th>UID</th>
                            <td><?= $user['users_uid']; ?></td>
                        </tr>
                        <tr>
                            <th>First Name</th>
                            <td><?= $user['users_fname']; ?></td>
                        </tr>
                        <tr>
                            <th>Last Name</th>
                            <td><?= $user['users_lname']; ?></td>
                        </tr>
                        <tr>
                            <th>Phone</th>
                            <td><?= $user['users_phone']; ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?= $user['users_email']; ?></td>
                        </tr>
                        <tr>
                <td colspan="2">
                    <a href="edit_user.php?user_id=<?= $user['users_id']; ?>">Edit User</a>
                </td>
            </tr>
                    </tbody>
                </table>
                <?php
            } else {
                echo "No user found for the specified ID or UID.";
            }
        } else {
            // Display all users initially
            $users = $dbhandler->connect()->query("SELECT * FROM usersacc")->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($users)) {
                ?>
                <table>
                    <thead>
                        <tr>
                            <th colspan="6"><h2>All Users</h2></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>ID</th>
                            <th>UID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                        </tr>
                        <?php foreach ($users as $user) : ?>
                            <tr>
                                <td><?= $user['users_id']; ?></td>
                                <td><?= $user['users_uid']; ?></td>
                                <td><?= $user['users_fname']; ?></td>
                                <td><?= $user['users_lname']; ?></td>
                                <td><?= $user['users_phone']; ?></td>
                                <td><?= $user['users_email']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php
            } else {
                echo "No users found.";
            }
        }
        ?>
    </div>
<?php endif; ?>

<?php include "includes/footer.inc.php"; ?>
