<?php

class DbHandler 
{
  public function connect()
  {
    try 
    {
      $servername = "localhost";
      $dbname = "cafedb";
      $username = "root";
      $password = "";

      $dbh = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      return $dbh;
    }
    catch (PDOException $e)
    {
      print "Error!: " . $e->getMessage() . "<br/>";
      die();
    }
  }
  public function getEmployeeID($ID)
    {
        try 
        {
            $dbh = $this->connect();
            $query = "SELECT employeeID FROM usersacc WHERE username = ?";
            $stmt = $dbh->prepare($query);
            $stmt->execute([$username]);

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            // Check if a result was found
            if ($result) {
                return $result['employeeID'];
            }

            // If no result found, return an appropriate value or handle it as needed
            return null;
        }
        catch (PDOException $e)
        {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
    } 
}

