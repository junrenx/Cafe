<?php
include "classes/dbhandler.class.php";

$dbhandler = new DbHandler;
$conn = $dbhandler->connect();

if (!$conn) {
    die("Database connection error: " . implode(" ", $dbhandler->errorInfo()));
}

if (isset($_POST['workslotid'])) {
    $workslotid = $_POST['workslotid'];

    // Check if the schedule exists
    $query = "SELECT * FROM schedule WHERE workslotid = :workslotid";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':workslotid', $workslotid);
    $stmt->execute();
    $schedule = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($schedule) {
        // Delete the schedule
        $deleteQuery = "DELETE FROM schedule WHERE workslotid = :workslotid";
        $deleteStmt = $conn->prepare($deleteQuery);
        $deleteStmt->bindParam(':workslotid', $workslotid);

        if ($deleteStmt->execute()) {
            // Redirect to the schedule view page with a success message
            header("Location: viewschedule.php?message=Schedule deleted successfully");
            exit();
        } else {
            echo "Error deleting schedule: " . implode(" ", $deleteStmt->errorInfo());
        }
    } else {
        echo "Schedule not found.";
    }
} else {
    echo "Workslot ID not provided.";
}

include "includes/footer.inc.php";
?>
