<?php
if (isset($_POST['submit'])) {
  include "../classes/dbhandler.class.php"; // Include your database connection

  // Get user input
  $usersType = $_POST['users_type'];
  $usersDesc = $_POST['users_desc'];

  // Validate user type length
  if (strlen($usersType) !== 2) {
      $error_message = "User type must be less than or just 2 characters in length.";
      header("Location: ../signupprofile.php?error=invalid_usertype&message=" . urlencode($error_message));
      exit();
  }

  // Check if the user type already exists
  $dbhandler = new Dbhandler();
  $query = "SELECT users_type FROM userstype WHERE users_type = :users_type";
  $stmt = $dbhandler->connect()->prepare($query);
  $stmt->bindParam(':users_type', $usersType, PDO::PARAM_STR);
  $stmt->execute();

  if ($stmt->fetch()) {
      // User type already exists
      $error_message = "User type already exists. Please choose a different user type.";
      header("Location: ../signupprofile.php?error=duplicate_entry&message=" . urlencode($error_message));
      exit();
  }

  // Insert the new user type
  $insertQuery = "INSERT INTO userstype (users_type, users_desc) VALUES (:users_type, :users_desc)";
  $insertStmt = $dbhandler->connect()->prepare($insertQuery);
  $insertStmt->bindParam(':users_type', $usersType, PDO::PARAM_STR);
  $insertStmt->bindParam(':users_desc', $usersDesc, PDO::PARAM_STR);

  if ($insertStmt->execute()) {
    // Successfully created the user type
    $success_message = "User type created successfully!";
    header("Location: ../adminviewprofile.php?success=" . urlencode($success_message));
    exit();
  } else {
      // Database error
      header("Location: ../signupprofile.php?error=database_error");
      exit();
  }
}
?>
