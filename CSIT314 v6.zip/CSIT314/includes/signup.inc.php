<?php
// Check if the form is submitted.
if (isset($_POST['submit'])) {
    // Include any necessary validation and database connection code here.
    
    // Define your form variables and sanitize user inputs.
    $username = $_POST['username'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $type = $_POST['users_type'];
    
    // Perform server-side validation (you can add more validation rules).
    if (empty($username) || empty($name) || empty($phone) || empty($email) || empty($password) || empty($type)) {
        header("Location: ../signup.php?error=emptyinput");
        exit();
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: ../signup.php?error=invalidemail");
        exit();
    }
    
    // Implement additional checks, such as verifying if the username or email is already in use in your database.
    
    // If all validation checks pass, you can proceed with user registration or other actions.
    
    // Securely hash the password.
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Establish a database connection (replace with your database credentials).
    $mysqli = new mysqli("localhost", "root", "", "cafedb");
    
    // Check for a connection error.
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }
    
    // Insert user data into the database, including the hashed password.
    $sql = "INSERT INTO usersacc (username, name, phone, email, password, users_type) VALUES (?, ?, ?, ?, ?, ?)";
    
    // Prepare the SQL statement.
    $stmt = $mysqli->prepare($sql);
    
    // Bind parameters and execute the query.
    $stmt->bind_param("ssssss", $username, $name, $phone, $email, $hashedPassword, $type);
    
    if ($stmt->execute()) {
        // Registration successful, redirect to a success page.
        header("Location: ../adminviewaccount.php");
    } else {
        // Registration failed, redirect with an error message.
        header("Location: ../signup.php?error=registrationfailed");
    }
    
    // Close the statement and the database connection.
    $stmt->close();
    $mysqli->close();
} else {
    // Handle cases where the form is not submitted.
    header("Location: ../signup.php"); // Redirect back to the signup page.
    exit();
}
