<?php include "includes/header.inc.php"; ?>
<?php include "includes/nav.inc.php"; ?>
<style>
    .message {
        text-align: center;
        color: #FF0000;
        padding: 10px;
    }
    </style>
<?php if (isset($_GET['message'])) {
    echo '<div class="message">' . $_GET['message'] . '</div>';
}?>
<?php include "includes/footer.inc.php"; ?>
