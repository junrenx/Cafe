<?php
include "includes/header.inc.php";
include "includes/nav.inc.php";
include "classes/dbhandler.class.php";

if (isset($_GET['month']) && isset($_GET['year'])) {
    $month = $_GET['month'];
    $year = $_GET['year'];
} else {
    $month = date("n");
    $year = date("Y");
}

$dbhandler = new DbHandler;
$conn = $dbhandler->connect();

if (!$conn) {
    die("Database connection error: " . implode(" ", $dbhandler->errorInfo()));
}

$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
$firstDayOfWeek = date("w", strtotime("{$year}-{$month}-01"));

$query = "SELECT schedule.*, usersacc.name
          FROM schedule
          INNER JOIN usersacc ON schedule.employeeID = usersacc.employeeID
          WHERE MONTH(schedule.date) = :month AND YEAR(schedule.date) = :year
          ORDER BY schedule.date, schedule.start_time";

$stmt = $conn->prepare($query);
$stmt->bindParam(":month", $month, PDO::PARAM_INT);
$stmt->bindParam(":year", $year, PDO::PARAM_INT);
$stmt->execute();

$scheduleData = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monthly Calendar</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .calendar {
            max-width: 1000px;
            margin: 0 auto;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        .calendar-caption {
            background-color: grey;
            color: #fff;
            text-align: center;
            padding: 20px 0;
            font-size: 24px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }
        th {
            background-color: grey;
            color: #fff;
        }
        td {
            background-color: #f9f9f9;
        }
        td:hover {
            background-color: grey;
            color: white;
            cursor: pointer;
        }
        .event {
            background-color: #b0e57c;
            border: 1px solid #6f996a;
            padding: 5px;
        }
    </style>
</head>
<body>
    <div class="calendar">
    <div class="calendar-caption">
    <a href="?month=<?php echo ($month - 1 < 1) ? 12 : ($month - 1); ?>&year=<?php echo ($month - 1 < 1) ? $year - 1 : $year; ?>">&#8592;</a>
    <?php echo date("F Y", strtotime("{$year}-{$month}-01")); ?>
    <a href="?month=<?php echo ($month + 1 > 12) ? 1 : ($month + 1); ?>&year=<?php echo ($month + 1 > 12) ? $year + 1 : $year; ?>">&#8594;</a>
</div>

        <table>
            <tr>
                <th>Sun</th>
                <th>Mon</th>
                <th>Tue</th>
                <th>Wed</th>
                <th>Thu</th>
                <th>Fri</th>
                <th>Sat</th>
            </tr>
            <tr>
                <?php
                $blankCells = $firstDayOfWeek;
                for ($i = 0; $i < $blankCells; $i++) {
                    echo '<td></td>';
                }
                for ($day = 1; $day <= $daysInMonth; $day++) {
                    $events = array_filter($scheduleData, function ($event) use ($day) {
                        return (int) date("d", strtotime($event['date'])) == $day;
                    });
                    $cellClass = count($events) > 0 ? 'event' : '';
                    echo '<td class="' . $cellClass . '">' . $day;
                    if (!empty($events)) {
                        echo '<ul>';
                        foreach ($events as $event) {
                            echo '<li>Staff Name:' . htmlspecialchars($event['name']) . '<br>';
                            echo 'Role: ' . htmlspecialchars($event['role']) . '<br>';
                            echo 'Time: ' . htmlspecialchars($event['start_time']) . ' - ' . htmlspecialchars($event['end_time']);
                            
                            echo '</li>';
                            echo '<br>';
                        }
                        echo '</ul>';
                    }
                    echo '</td>';
                    if (($blankCells + $day) % 7 == 0) {
                        echo '</tr>';
                        if ($day < $daysInMonth) {
                            echo '<tr>';
                        }
                    }
                }
                $remainingDays = 7 - (($blankCells + $daysInMonth) % 7);
                for ($i = 0; $i < $remainingDays; $i++) {
                    echo '<td></td>';
                }
                ?>
            </tr>
        </table>
    </div>
</body>
</html>
