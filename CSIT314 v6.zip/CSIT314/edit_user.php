<style>
  /* Common styles for container and form */
  .container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #fff; /* Light gray background color */
    color: #333; /* Dark text color */
  }

  /* Form styles */
  form {
    background-color: #fff; /* White background for the form */
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    width: 100%;
    text-align: center;
  }

  form label {
    font-weight: bold;
    display: block;
    margin-bottom: 10px;
  }

  form input[type="text"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc; /* Light gray border color */
    border-radius: 5px;
    font-size: 16px;
    background-color: #f7f7f7; /* Slightly darker input background color */
    color: #333; /* Dark text color */
    margin-bottom: 15px;
  }

  form input[type="submit"] {
    background-color: #0073e6; /* Blue button background color */
    color: #fff; /* White text color */
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
  }

  form input[type="submit"]:hover {
    background-color: #0050a2; /* Darker blue on hover */
  }

  /* Error message styles */
  form p {
    color: #ff5555; /* Red text color for error messages */
    font-weight: bold;
  }
  .update-button {
    background-color: #4CAF50; /* Green button background color */
    color: #fff; /* White text color */
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.update-button:hover {
    background-color: #45a049; /* Darker green on hover */
}

/* Style the select element */
select#users_type {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc; /* Light gray border color */
    border-radius: 5px;
    font-size: 16px;
    background-color: #f7f7f7; /* Slightly darker input background color */
    color: #333; /* Dark text color */
    margin-bottom: 15px;
}

/* Style the select options */
select#users_type option {
    background-color: #fff; /* White background for options */
    color: #333; /* Dark text color for options */
}

/* Style the selected option */
select#users_type option[selected] {
    background-color: #0073e6; /* Blue background color for the selected option */
    color: #fff; /* White text color for the selected option */
}

/* Style the select on hover */
select#users_type:hover {
    border-color: #0050a2; /* Darker border color on hover */
}
/* Style the success message */
.success-message {
    color: #4CAF50; /* Green text color for success */
    font-weight: bold;
}

/* Style the error message */
.error-message {
    color: #FF5733; /* Red text color for error */
    font-weight: bold;
}
</style>
<?php
include "classes/dbhandler.class.php";
$dbhandler = new Dbhandler;
include "includes/header.inc.php";
?>

<style>
  /* Common styles for container and form */
  /* ... (your CSS styles here) */
</style>

<?php
if ($_SESSION['type'] == "SA") {
    if (isset($_GET['user_id'])) {
        $username = $_GET['user_id'];

        // Fetch user descriptions ("users_desc") from the "userstype" table
        $userTypesQuery = "SELECT * FROM userstype";
        $userTypesStmt = $dbhandler->connect()->query($userTypesQuery);
        $userTypeDescriptions = $userTypesStmt->fetchAll(PDO::FETCH_ASSOC);

        // Retrieve user data based on the provided username
        $query = "SELECT * FROM usersacc WHERE username = :username";
        $stmt = $dbhandler->connect()->prepare($query);
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                // Handle form submission for updating user details
                $newUsername = $_POST['username'];
                $newUsersType = $_POST['users_type'];
                $newName = $_POST['name'];
                $newPhone = $_POST['phone'];
                $newEmail = $_POST['email'];

                $updateQuery = "UPDATE usersacc SET username = :newUsername, users_type = :newUsersType, name = :name, phone = :phone, email = :email WHERE username = :username";
                $updateStmt = $dbhandler->connect()->prepare($updateQuery);
                $updateStmt->bindParam(':newUsername', $newUsername, PDO::PARAM_STR);
                $updateStmt->bindParam(':newUsersType', $newUsersType, PDO::PARAM_STR);
                $updateStmt->bindParam(':name', $newName, PDO::PARAM_STR);
                $updateStmt->bindParam(':phone', $newPhone, PDO::PARAM_STR);
                $updateStmt->bindParam(':email', $newEmail, PDO::PARAM_STR);
                $updateStmt->bindParam(':username', $username, PDO::PARAM_STR);

                if ($updateStmt->execute()) {
                    echo '<p class="success-message">User details updated successfully.</p>';
                } else {
                    echo '<p class="error-message">Error updating user details.</p>';
                }

                
            }

            // Display the user's current details and provide a form for editing
            ?>
            <div class="container">
                <form method="POST">
                    <label for="username">Username:</label>
                    <input type="text" name="username" id="username" value="<?= $user['username'] ?>" required>

                    <label for="name">Name:</label>
                    <input type="text" name="name" id="name" value="<?= $user['name'] ?>" required>

                    <label for="phone">Phone:</label>
                    <input type="text" name="phone" id="phone" value="<?= $user['phone'] ?>" required>

                    <label for="email">Email:</label>
                    <input type="text" name="email" id="email" value="<?= $user['email'] ?>" required>

                    <label for="users_type">User Type:</label>
                    <select name="users_type" id="users_type" required>
                        <?php foreach ($userTypeDescriptions as $typeData) : ?>
                            <option value="<?= $typeData['users_type'] ?>" <?= ($typeData['users_type'] === $user['users_type']) ? 'selected' : '' ?>>
                                <?= $typeData['users_desc'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <input type="submit" value="Update User" class="update-button">
                </form>
            </div>
        <?php
        } else {
            echo "<p class='error-message'>User not found for the specified username.</p>";
        }
    } else {
        echo "<p class='error-message'>No username specified for editing.</p>";
    }
}
?>

<?php include "includes/footer.inc.php"; ?>
