<?php
include "classes/dbhandler.class.php";

$dbhandler = new DbHandler;
$conn = $dbhandler->connect();

if (!$conn) {
    die("Database connection error: " . implode(" ", $dbhandler->errorInfo()));
}

include "includes/header.inc.php";
include "includes/nav.inc.php";
include "includes/footer.inc.php";
?>
