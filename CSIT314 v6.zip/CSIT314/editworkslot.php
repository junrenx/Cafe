<?php
include "classes/dbhandler.class.php";

$dbhandler = new DbHandler;
$conn = $dbhandler->connect();

if (!$conn) {
    die("Database connection error: " . implode(" ", $dbhandler->errorInfo()));
}

include "includes/header.inc.php";
include "includes/nav.inc.php";
?>

<style>
        .form-container {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="date"],
        input[type="time"],
        select {
            width: 90%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        input[type="submit"],
        button[type="button"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            margin-top: 20px;
            border-radius: 4px;
            font-size: 18px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }
    </style>



<?php
if (isset($_GET['id'])) {
    $workslotid = $_GET['id'];

    $query = "SELECT * FROM schedule WHERE workslotid = :workslotid";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':workslotid', $workslotid);
    $stmt->execute();
    $schedule = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($schedule) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Handle form submission for updating the schedule
            // You can add your update logic here

            // Example code to update a schedule
            $newDate = $_POST['newDate'];
            $newStartTime = $_POST['newStartTime'];
            $newEndTime = $_POST['newEndTime'];
            $newrole = $_POST['newrole'];
            $newEmployeeID = $_POST['newEmployeeID'];

            $updateQuery = "UPDATE schedule SET date = :newDate, start_time = :newStartTime, end_time = :newEndTime, role = :newrole, employeeID = :newEmployeeID WHERE workslotid = :workslotid";
            $updateStmt = $conn->prepare($updateQuery);
            $updateStmt->bindParam(':newDate', $newDate);
            $updateStmt->bindParam(':newStartTime', $newStartTime);
            $updateStmt->bindParam(':newEndTime', $newEndTime);
            $updateStmt->bindParam(':newrole', $newrole);
            $updateStmt->bindParam(':newEmployeeID', $newEmployeeID);
            $updateStmt->bindParam(':workslotid', $workslotid);

            if ($updateStmt->execute()) {
                // Redirect to the schedule view page with a success message
                header("Location: viewschedule.php?message=Schedule updated successfully");
                exit(); 
            } else {
                echo "Error updating schedule: " . implode(" ", $updateStmt->errorInfo());
            }
        }
?>

<div class="form-container">
    <h1>Edit Schedule</h1>
    <form method="POST" id="editForm">
    <input type="hidden" name="workslotid" value="<?php echo $workslotid; ?>">
        <div class="form-group">
            <label for="newDate">Date:</label>
            <input type="date" name="newDate" value="<?php echo $schedule['date']; ?>" required>
        </div>
        <div class="form-group">
            <label for="newStartTime">Start Time:</label>
            <input type="time" name="newStartTime" value="<?php echo $schedule['start_time']; ?>" required>
        </div>
        <div class="form-group">
            <label for="newEndTime">End Time:</label>
            <input type="time" name="newEndTime" value="<?php echo $schedule['end_time']; ?>" required>
        </div>
        <div class="form-group">
        <label for="newrole">Role</label>
<select name="newrole" required>
    <option value="chef" <?php if ($schedule['role'] === 'chef') echo 'selected'; ?>>Chef</option>
    <option value="cashier" <?php if ($schedule['role'] === 'cashier') echo 'selected'; ?>>Cashier</option>
    <option value="waiter" <?php if ($schedule['role'] === 'waiter') echo 'selected'; ?>>Waiter</option>
</select><br>

            
        </div>
        <div class="form-group">
            <label for="newEmployeeID">Employee ID:</label>
            <select name="newEmployeeID" id="newEmployeeID" required>
            <?php
                    // Replace this part with PDO code to fetch employee data
                    $employeeQuery = "SELECT employeeID, name FROM usersacc WHERE users_type = 'CS'";
                    $employeeStmt = $conn->prepare($employeeQuery);
                    $employeeStmt->execute();

                    while ($row = $employeeStmt->fetch(PDO::FETCH_ASSOC)) {
                        $selected = ($row['employeeID'] == $schedule['employeeID']) ? "selected" : "";
                        echo '<option value="' . $row['employeeID'] . '" ' . $selected . '>' . $row['name'] . '</option>';
                    }
                    ?>  
                    </select>
        </div>
        <div class="form-group">
        <input type="submit" value="Update Schedule">
            <!-- Add a "Delete" button and call the JavaScript function when clicked -->
            <button type="button" id="deleteButton" onclick="showDeleteConfirmation()">Delete Schedule</button>
        </div>
    </form>
</div>

<script>
    // JavaScript function to show the delete confirmation dialog
    function showDeleteConfirmation() {
        if (confirm("Are you sure you want to delete this schedule?")) {
            // If the user confirms, submit the form to delete the schedule
            document.getElementById('editForm').action = 'deleteschedule.php'; // Update with the actual delete script
            document.getElementById('editForm').submit();
        }
    }
</script>

<?php
    } else {
        echo "Schedule not found.";
    }
} else {
    echo "Workslot ID not provided.";
}

include "includes/footer.inc.php";
?>
