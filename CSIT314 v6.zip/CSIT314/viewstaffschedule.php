<?php
include "classes/dbhandler.class.php";

$dbhandler = new DbHandler;
$conn = $dbhandler->connect();

if (!$conn) {
    die("Database connection error: " . implode(" ", $dbhandler->errorInfo()));
}

include "includes/header.inc.php";
include "includes/nav.inc.php";
?>


<style>
    h1 {
        text-align: center;
        margin: 20px;
        color: #333;
    }

    table {
        width: 50%;
        border-collapse: collapse;
        margin: 0 auto; /* Center-align the table */
    }

    th, td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ccc;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    tr:nth-child(odd) {
        background-color: #fff;
    }

    .message {
        text-align: center;
        color: #FF0000;
        padding: 10px;
    }
</style>

<?php 
echo '<h1>View Own Schedule</h1>';
if (isset($_GET['message'])) {
    echo '<div class="message">' . $_GET['message'] . '</div>';
}?>
<?php

$dbhandler = new DbHandler;
$conn = $dbhandler->connect();

// Assuming $user is from the $_SESSION['user'] variable
$user = $_SESSION['user'];

$query = "SELECT schedule.*, usersacc.name
          FROM schedule
          INNER JOIN usersacc ON schedule.employeeID = usersacc.employeeID
          WHERE usersacc.name = :user
          ORDER BY schedule.date, schedule.start_time";

$stmt = $conn->prepare($query);
$stmt->bindParam(':user', $user, PDO::PARAM_STR);
$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);


if ($result) {
    if (count($result) > 0) {
        echo "<table>
        <tr>
            <th>Date</th>
            <th>Role</th>
            <th>Start Time</th>
            <th>End Time</th>
        </tr>";

        foreach ($result as $row) {
            echo "<tr>
                <td>" . htmlspecialchars($row['date']) . "</td>
                <td>" . htmlspecialchars($row['role']) . "</td>
                <td>" . htmlspecialchars($row['start_time']) . "</td>
                <td>" . htmlspecialchars($row['end_time']) . "</td>
            </tr>";
        }

        echo "</table>";
    } else {
        echo "No schedules found.";
    }
} else {
    echo "Error: Unable to fetch schedule data.";
}

include "includes/footer.inc.php";
?>
