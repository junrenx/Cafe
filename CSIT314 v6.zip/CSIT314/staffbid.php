<?php
include "includes/header.inc.php";
include "includes/nav.inc.php";

// Check if the user is logged in and has a name in the session.
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user']; // Store the name in a variable
} else {
    // Handle the case where the user is not logged in or employeeID is not in the session.
    // You can redirect them to a login page or take appropriate action.
    // For example:
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Bidding Form</title>
    <style>
        .form-container {
            width: 20%;
            margin: 0 auto;
            padding: 30px;
            border: 1px solid #ccc;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        .form-group {
            margin-bottom: 10px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="date"],
        input[type="number"],
        input[type="time"],
        select {
            width: 80%;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        input[type="submit"],
        button[type="button"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            margin-top: 20px;
            border-radius: 4px;
            font-size: 18px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Bidding</h1>
        <form method="POST" action="process_form.php">
            <label for="employeeid">Employee ID: <?php echo $user; ?></label>
            <input type="hidden" name="employeeid" id="employeeid" value="<?php echo $user; ?>" required>
            <br>

            <div class="form-group">
                <label for="workslotid">Work slot ID</label>
                <select name="workslotid" id="workslotid" required>
                    <?php
                    // Assuming you have a database connection established
                    $connection = new mysqli("localhost", "root", "", "cafedb");

                    if (!$connection->connect_error) {
                        $query = "SELECT * FROM schedule";
                        $result = $connection->query($query);

                        if ($result) {
                            while ($row = $result->fetch_assoc()) {
                                echo '<option value="' . $row['workslotid'] . '">' . $row['workslotid'] . '</option>';
                            }
                        }

                        $connection->close();
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="role">Role:</label>
                <span id="displayRole"></span><br>
            </div>
            <input type="hidden" name="role" id="roleField" value="" required>

            <div class="form-group">
                <label for="date">Date:</label>
                <span id="displayDate"></span><br>
            </div>

            <!-- default as 1 -->
            <input type="hidden" name="max_slots" value="1" required><br>
            <input type="submit" value="Bid">
        </form>
    </div>

    <script>
    // Function to update both Role and Date based on selected Workslot
    function updateRoleAndDate(selectedWorkslotId) {
        var displayRole = document.getElementById('displayRole');
        var displayDate = document.getElementById('displayDate');

        // Clear the role and date text
        displayRole.textContent = '';
        displayDate.textContent = '';

        // Make an AJAX request to fetch the role and date based on the selected workslotid
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'fetch_role_and_date.php?workslotid=' + selectedWorkslotId, true);

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                var data = JSON.parse(xhr.responseText);

                if (data.role) {
                    // Display the role text
                    displayRole.textContent = data.role;
                    // Set the value of the hidden input field for "role"
                    roleField.value = data.role;
                }

                if (data.date) {
                    // Display the date text
                    displayDate.textContent = data.date;
                }
            }
        };

        xhr.send();
    }

    document.getElementById('workslotid').addEventListener('change', function () {
        var selectedWorkslotId = this.value;
        updateRoleAndDate(selectedWorkslotId);
    });

    // Initial call to populate Role and Date based on the default selected workslot
    var initialWorkslotId = document.getElementById('workslotid').value;
    updateRoleAndDate(initialWorkslotId);
</script>
</body>
</html>
