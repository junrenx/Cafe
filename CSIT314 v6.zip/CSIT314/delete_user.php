<?php
include "classes/dbhandler.class.php";
$dbhandler = new Dbhandler;

if (isset($_GET['user_id'])) {
    $username = $_GET['user_id'];

    // Check if the user exists
    $query = "SELECT * FROM usersacc WHERE username = :username";
    $stmt = $dbhandler->connect()->prepare($query);
    $stmt->bindParam(':username', $username, PDO::PARAM_STR);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        if (isset($_GET['confirmed']) && $_GET['confirmed'] === "true") {
            // Delete the user
            $deleteQuery = "DELETE FROM usersacc WHERE username = :username";
            $deleteStmt = $dbhandler->connect()->prepare($deleteQuery);
            $deleteStmt->bindParam(':username', $username, PDO::PARAM_STR);

            if ($deleteStmt->execute()) {
                // Redirect back to adminviewaccount.php after successful deletion
                header("Location: adminviewaccount.php");
                exit(); // Ensure script termination after redirection
            } else {
                echo "Failed to delete the user. Please try again.";
            }
        } else {
            echo "User with username $username exists. Are you sure you want to delete this user? <a href='delete_user.php?user_id=$username&confirmed=true'>Confirm</a>";
        }
    } else {
        echo "User not found for the specified username.";
    }
} else {
    echo "Invalid user ID provided.";
}
?>
