<?php
include "includes/header.inc.php";
include "classes/dbhandler.class.php";
include "includes/nav.inc.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle form submission
    $dbhandler = new DbHandler;
    $conn = $dbhandler->connect(); // Use the connect method to establish a database connection

    // Sanitize and validate user input
    $employeeID = $_POST['employeeID'];
    $date = $_POST['date'];
    $role = $_POST['role'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    // Create a prepared statement
    $stmt = $conn->prepare("INSERT INTO schedule (employeeID, date, role, start_time, end_time) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$employeeID, $date, $role, $start_time, $end_time]);

    if ($stmt) {
        header("Location: viewschedule.php?message=Work slot created successfully.");
    } else {
        echo "Error: " . implode(" ", $stmt->errorInfo());
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Work Slot</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        form {
            background-color: #fff;
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        select, input[type="date"], input[type="text"], input[type="time"] {
            width: 90%;
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        select {
            height: 40px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            font-size: 18px;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Add Work Slot</h1>
    <form method="POST">
        <label for="employeeID">Employee Name:</label>
        <select name="employeeID" id="employeeID" required>
            <?php
            // Assuming you have a database connection established
            $connection = mysqli_connect("localhost", "root", "", "cafedb");

            // Check if the connection was successful
            if ($connection) {
                $query = "SELECT employeeID, name FROM usersacc WHERE users_type = 'CS'";
                $result = mysqli_query($connection, $query);

                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo '<option value="' . $row['employeeID'] . '">' . $row['name'] . '</option>';
                    }
                }

                // Close the database connection
                mysqli_close($connection);
            }
            ?>
        </select><br>

        <label for="date">Date:</label>
        <input type="date" name="date" required><br>

        <label for="role">Role</label>
<select name="role" required>
    <option value="chef">Chef</option>
    <option value="cashier">Cashier</option>
    <option value="waiter">Waiter</option>
</select><br>


        <label for="start_time">Start Time:</label>
        <input type="time" name="start_time" required><br>

        <label for="end_time">End Time:</label>
        <input type="time" name="end_time" required><br>

        <input type="submit" value="Add Work Slot">
    </form>
</body>
</html>
