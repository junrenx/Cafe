<?php
include "classes/dbhandler.class.php";
$dbhandler = new Dbhandler;
include "includes/header.inc.php";?>
<style>/* Common styles for container and form */
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #fff; /* Light gray background color */
  color: #333; /* Dark text color */
}

/* Form styles */
form {
  background-color: #fff; /* White background for the form */
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  max-width: 400px;
  width: 100%;
  text-align: center;
}

form label {
  font-weight: bold;
  display: block;
  margin-bottom: 10px;
}

form input[type="text"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc; /* Light gray border color */
  border-radius: 5px;
  font-size: 16px;
  background-color: #f7f7f7; /* Slightly darker input background color */
  color: #333; /* Dark text color */
  margin-bottom: 15px;
}

form input[type="submit"] {
  background-color: #0073e6; /* Blue button background color */
  color: #fff; /* White text color */
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s;
}

form input[type="submit"]:hover {
  background-color: #0050a2; /* Darker blue on hover */
}

/* Table styles for user details */
table {
  width: 100%;
  border-collapse: collapse;
  background-color: #fff; /* White background for the table */
  color: #333; /* Dark text color */
}

table th, table td {
  border: 1px solid #ccc; /* Light gray border color for table */
  padding: 10px;
  text-align: center;
}

/* Error message styles */
form p {
  color: #ff5555; /* Red text color for error messages */
  font-weight: bold;
}
</style>
<?php if ($_SESSION['type'] == "SA") : ?>
    <div class="container">
        <form method="POST">
            <label for="search">Search Profile by User Type or Description:</label>
            <input type="text" name="search" id="search">
            <input type="submit" value="Search">
        </form>

        <?php
        if (isset($_POST['search'])) {
            $searchValue = $_POST['search'];

            // Modify the SQL query to retrieve data for the selected user based on ID or UID
            $query = "SELECT * FROM userstype WHERE users_type = :searchValue OR users_desc = :searchValue";
            $stmt = $dbhandler->connect()->prepare($query);
            $stmt->bindParam(':searchValue', $searchValue, PDO::PARAM_STR);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Display user details
                ?>
                <table>
                    <thead>
                        <tr>
                            <th colspan="2"><h2>User Profile</h2></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>User Type</th>
                            <td><?= $user['users_type']; ?></td>
                        </tr>
                        <tr>
                            <th>User Description</th>
                            <td><?= $user['users_desc']; ?></td>
                        </tr>
                        <tr>
                <td colspan="2">
                </td>
            </tr>
                    </tbody>
                </table>
                <?php
            } else {
              echo "<p>No user profile found</p>";
            }
        } else {
            // Display all users profile initially
            $users = $dbhandler->connect()->query("SELECT * FROM userstype")->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($users)) {
                ?>
                <table>
                    <thead>
                        <tr>
                            <th colspan="6"><h2>All Users Profile</h2></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>User Type</th>
                            <th>User Description</th>
                        </tr>
                        <?php foreach ($users as $user) : ?>
                            <tr>
                                <td><?= $user['users_type']; ?></td>
                                <td><?= $user['users_desc']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php
            } else {
                echo "<p>No users profile found.</p>";
            }
        }
        ?>
    </div>
<?php endif; ?>

<?php include "includes/footer.inc.php"; ?>
