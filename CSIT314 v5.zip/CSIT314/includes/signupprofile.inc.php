<?php
  if(isset($_POST["submit"]))
  {
    // Retrieve form data
    $userstype = $_POST["users_type"];
    $usersdesc = $_POST["users_desc"];

    // Instantiate SignupController class
    include "../classes/dbhandler.class.php";
    include "../classes/signupprofile.class.php";
    include "../classes/signup-controllerprofile.class.php";
    
    $signup = new SignupController($userstype, $usersdesc);

    // Run error handlers
    $signup->signupUser();

    // Return to signup.php page
    header("location: ../signup.php?error=none");
  }