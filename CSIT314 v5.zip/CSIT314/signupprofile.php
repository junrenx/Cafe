<!DOCTYPE html>
<html lang="en">
<?php include "includes/header.inc.php"; ?>
<style>
/* Common styles for form and footer */
.body-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background-color: #f0f0f0; /* Light gray background color */
  color: #333; /* Dark text color */
}

/* Form styles */
form {
  background-color: #fff; /* White background for the form */
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  max-width: 400px;
  width: 100%;
  text-align: center;
}

.form-group {
  margin-bottom: 15px;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 5px;
}

input[type="text"],
input[type="tel"],
input[type="email"],
input[type="password"] {
  width: 80%;
  padding: 10px;
  border: 1px solid #ccc; /* Light gray border color */
  border-radius: 5px;
  font-size: 16px;
  background-color: #f7f7f7; /* Light gray input background color */
  color: #333; /* Dark text color */
}

.radio-group {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 10px;
  margin-top: 10px;
}

/* Footer styles */
footer {
  text-align: center;
  margin-top: 20px;
}

footer p {
  color: #ff5555; /* Red text color for error messages */
  font-weight: bold;
}

/* Style the submit button */
button[type="submit"] {
  background-color: #0073e6; /* Blue button background color */
  color: #fff; /* White text color */
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s;
}

button[type="submit"]:hover {
  background-color: #0050a2; /* Darker blue on hover */
}


</style>
<body>
  <div class="body-container">
    <form action="includes/signupprofile.inc.php" method="post">
      <div class="form-group">
        <label for="users_type">UserType</label>
        <input type="text" id="users_type" name="users_type" placeholder="User type" required>
      </div>

      <div class="form-group">
        <label for="user_desc">User Description</label>
        <input type="text" id="users_desc" name="users_desc" placeholder="Description" required>
      </div>

      <div class="form-group">
        <button type="submit" name="submit">Create</button>
      </div>
    </form>

    <footer>
      <?php
        if (isset($_GET['error'])) {
          if ($_GET['error'] == 'none') {
            echo "<p>You have created successfully!</p>";
          }
        }
      ?>
    </footer>
  </div>
</body>
</html>
