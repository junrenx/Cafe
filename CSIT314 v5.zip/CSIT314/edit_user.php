<?php
include "classes/dbhandler.class.php";
$dbhandler = new Dbhandler;

include "includes/header.inc.php";

// Check if the user is logged in and is an admin (adjust this condition based on your authentication)
if ($_SESSION['type'] != "SA") {
    echo "Access denied. You must be an admin to edit user details.";
} else {
    if (isset($_GET['user_id'])) {
        $userId = $_GET['user_id'];

        // Check if the user ID is valid (you may want to add additional validation)
        if (!is_numeric($userId)) {
            echo "Invalid user ID.";
        } else {
            // Handle form submission to update user details
            if (isset($_POST['update'])) {
                // Retrieve and validate form data
                $newFirstName = $_POST['first_name'];
                $newLastName = $_POST['last_name'];
                $newPhone = $_POST['phone'];
                $newEmail = $_POST['email'];

                // Update user details in the database
                $query = "UPDATE usersacc SET users_fname = :fname, users_lname = :lname, users_phone = :phone, users_email = :email WHERE users_id = :userId";
                $stmt = $dbhandler->connect()->prepare($query);
                $stmt->bindParam(':fname', $newFirstName, PDO::PARAM_STR);
                $stmt->bindParam(':lname', $newLastName, PDO::PARAM_STR);
                $stmt->bindParam(':phone', $newPhone, PDO::PARAM_STR);
                $stmt->bindParam(':email', $newEmail, PDO::PARAM_STR);
                $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);

                if ($stmt->execute()) {
                    echo "User details updated successfully.";
                } else {
                    echo "Failed to update user details.";
                }
            }

            // Retrieve the current user details
            $query = "SELECT * FROM usersacc WHERE users_id = :userId";
            $stmt = $dbhandler->connect()->prepare($query);
            $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Display the user details and an edit form
                ?>
                <h2>Edit User Details</h2>
                <form method="POST">
                    <label for="first_name">First Name:</label>
                    <input type="text" name="first_name" value="<?= $user['users_fname'] ?>"><br>
                    <label for="last_name">Last Name:</label>
                    <input type="text" name="last_name" value="<?= $user['users_lname'] ?>"><br>
                    <label for="phone">Phone:</label>
                    <input type="number" name="phone" value="<?= $user['users_phone'] ?>"><br>
                    <label for="email">Email:</label>
                    <input type="email" name="email" value="<?= $user['users_email'] ?>"><br>
                    <input type="submit" name="update" value="Update">
                </form>
                <?php
            } else {
                echo "User not found.";
            }
        }
    } else {
        echo "User ID not specified.";
    }
}
include "includes/footer.inc.php";
?>
