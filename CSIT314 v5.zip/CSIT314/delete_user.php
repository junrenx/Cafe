<?php
include "classes/dbhandler.class.php";
$dbhandler = new Dbhandler;

include "includes/header.inc.php";

if (isset($_GET['user_id']) && is_numeric($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Check if the user exists
    $query = "SELECT * FROM usersacc WHERE users_id = :user_id";
    $stmt = $dbhandler->connect()->prepare($query);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Delete the user
        $deleteQuery = "DELETE FROM usersacc WHERE users_id = :user_id";
        $deleteStmt = $dbhandler->connect()->prepare($deleteQuery);
        $deleteStmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);

        if ($deleteStmt->execute()) {
            echo "User with ID $user_id has been deleted successfully.";
        } else {
            echo "Failed to delete the user. Please try again.";
        }
    } else {
        echo "User with ID $user_id not found.";
    }
} else {
    echo "Invalid user ID provided.";
}
